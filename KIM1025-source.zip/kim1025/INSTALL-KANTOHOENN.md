# KantoHoenn companion updates

Install 1025Dex 1.2.11, KIM1025 1.6.16 and WildFollowers 2.22.14 by replacing the older copies of those same mod IDs. Enable them alongside KantoHoenn 0.1.0 in the stock gen1recomp 0.3.51 app. Leave 1025DexNav 0.1.13 installed: it already reads the live Dex API. Restart the current game session after updating.

Choose WILD GENS = GEN 1-9 for the full regional distribution. KantoHoenn must be enabled and successfully loaded; without it 1025Dex retains its original standalone encounter pools. No ROMs or app modifications are included in these updates. The campaign still uses your separately imported FireRed/Emerald files.

The wild atlas assigns 512 species to Kanto and 513 to Hoenn. It derives homes from the supplied ROMs' real encounter channels and the existing habitat/level policy. Most species have one primary and one alternate home per channel, with small local fallback pools where needed. Kanto-native Gen 1 and Hoenn-native Gen 3 entries are preferentially retained where the existing legal pool offers them. Later species balance the two regions. Native scripted gifts, bosses, roamers, starters and story encounters remain controlled by the games; these can overlap the regional wild roster. Legendary/mythical additions and Ultra Beasts retain their existing League-clear gates.

For narrower generation options, up to three selected-generation visitors fill an otherwise empty regional ordinary pool. This keeps those options usable. Route 1's permanent beginner encounters and Diglett's Cave's weighted native residents retain their existing exceptions.

EncounterAtlas.csv inside 1025Dex lists every species' region, level gate, postgame requirement and full-roster wild homes (including small fallback homes). Native scripted encounters are not listed. Saving/loading or region travel requires no new save format for this update.

WildFollowers uses the same Dex selection API. Its update only invalidates and refreshes cached encounter populations when campaign mode changes; existing movement, follower presentation and spawn settings remain unchanged. DexNav uses the same live pools.

KIM uses Emerald's final, resolved battle environment ID, including trainer/story overrides, rather than FRLG environment assumptions. Grass, sea, forest and suitable caves use existing HD art. Desert/sand, underwater, freshwater ponds, mountain/volcanic/ash areas, Mt. Pyre, indoor battles, Frontier, gyms/leaders, Elite Four/champion, teams and the weather trio keep the native Emerald background when no suitable Hoenn HD scene exists. This update adds routing, not new Hoenn artwork. Turn HD BATTLE BACKGROUNDS off to use native backgrounds everywhere.

Validation is headless. Complete graphical playthroughs and live region-switch rendering have not been run. See VALIDATION-KANTOHOENN.md for the exact checks and limits.
