# Complete aspect arenas — 1.6.30

Portrait and 16:9 layouts select a single complete HD arena image, including the original battle mounds. These replace the previous layered backdrop rendering in the flat HD battle renderer.

There are 72 canonical scenes and time variants, with 144 complete aspect images. Each location has matching surrounding scenery, including caves, water, gyms and interiors. The original 1920×950 arena is embedded at a fixed offset and scale. The existing ground anchors, Pokémon positions, native-fit transformations and portrait screen lift remain in use.

`data/aspect_battle_backgrounds.lua` maps the baked image back to the original arena coordinate system. Portrait assets are 1920×3413, widescreen assets are 1920×1080. Both contain the original arena at half source resolution. Image encoding uses high-quality JPEG; preservation refers to mound geometry and placement, not lossless pixel encoding.

The loader retains only the currently selected complete arena texture. If an asset cannot load, it falls back to the canonical arena. The previous backdrop blend shader is no longer used. Existing native generation-specific background paths remain available.

Validation includes Lua parsing, all 72 arena transforms across portrait, wide and native-fit viewports, ground alignment, single-draw rendering on Windows/Linux/macOS/Android/iOS, and existing Hoenn and asset-manager tests. Mobile host rendering is exercised with test doubles, rather than a physical device.

Install the single release ZIP, replacing the previous KIM1025 folder. Retain your downloaded KIM asset cache.
