local n=0
local function check(v,m) n=n+1; assert(v,m) end
local Manager={}
local saved={animate=false,battlePlayerSize=150}
function Manager:buildOptionRows(m,schema)
 local rows={}
 for _,d in ipairs(schema) do
  local key=d.key
  rows[#rows+1]={id=key,label=key,step=function(_,v) saved[key]=v end}
 end
 rows[#rows+1]={id='__reset',label='RESET DEFAULTS'}
 return rows
end
function Manager:openOptions(m)
 self.currentMod=m; self.optionRows=self:buildOptionRows(m,self.schema); self.screen='options';self.cursor=1
end
function Manager:goBack() self.exited=true end
package.loaded['src.mods.ManagerState']=Manager
local groups=assert(loadfile('lib/settings_groups.lua'))()({})
local schema={{key='animate'},{key='battlePlayerSize'},{key='battleSprites'},{key='battleHudOpacity'},
 {key='battleMoveInfo'},{key='theme'},{key='titleScreen'}}
local state=setmetatable({schema=schema},{__index=Manager})
state:openOptions({id='kim1025'})
check(#state.optionRows==5,'only categories on root')
check(saved.animate==false and saved.battlePlayerSize==150,'saved values retained')
local function choose(id)
 for i,r in ipairs(state.optionRows) do if r.id==id then state.cursor=i;r.activate();return end end
 error('missing '..id)
end
choose('__kim_group:battle');choose('__kim_group:battle/sizing')
check(#state.optionRows==1 and state.optionRows[1].id=='battlePlayerSize','sizing leaf only')
state.optionRows[1].step(nil,175)
check(saved.battlePlayerSize==175,'native callback preserved')
state.optionRows=state:buildOptionRows(state.currentMod,schema)
check(state.optionRows[1].id=='battlePlayerSize','native rebuild preserves submenu')
state:goBack()
check(not state.exited and state.optionRows[state.cursor].id=='__kim_group:battle/sizing','B restores cursor')
state:goBack()
check(state.optionRows[state.cursor].id=='__kim_group:battle','B restores root')
state:goBack();check(state.exited,'root B exits')
state:openOptions({id='other'})
check(#state.optionRows==#schema+1 and not state._kimGroupedOptions,'other mods unaffected')
state:openOptions({id='kim1025'})
check(state.optionRows[1].id=='__kim_group:pokemon','reopen at root')
local list={index=1,game={}}
local assets={id='kim1025:asset_manager',label='KIM ASSETS',assetManager=true}
local source={{id='kim1025:animate',option={key='animate',default=true}},
 {id='kim1025:battlePlayerSize',option={key='battlePlayerSize',default=100}},assets}
groups.setOption=function(_,k,v) saved[k]=v end
groups.apply(list,source,'list')
check(list.items[#list.items-1]==assets,'asset downloader on root')
list.items[2].activate();list.items[1].activate()
check(list.items[1]==source[2],'original ListMenu descriptor retained')
list.items[#list.items-1].activate()
check(saved.battlePlayerSize==100 and saved.animate==false,'reset only current section')
check(groups.back(list) and groups.back(list) and not groups.back(list),'ListMenu back navigation')
check(groups.pathFor({id='gen3IntegratedModernUi'})=='interface/general','Gen3 master')
check(groups.pathFor({id='gen2UiTheme'})=='interface/appearance','Gen2 theme')
check(groups.pathFor({id='gen3FontScale'})=='interface/fonts','Gen3 font')
print('settings groups: '..n..' checks passed')
