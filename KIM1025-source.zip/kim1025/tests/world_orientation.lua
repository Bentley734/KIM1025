local root=arg[1] or '../engine-release'
local function read(p)local f=assert(io.open(p));local s=f:read('*a');f:close();return s end
local checks=0
local function eq(a,b,label)checks=checks+1;assert(a==b,label..': '..tostring(a)..' ~= '..tostring(b))end
for _,case in ipairs({{'iOS',12,true},{'iOS',11,true},{'Android',12,true},{'Windows',12,true},{'OS X',12,true},{'iOS',12,false},{'iOS',11,false},{'Android',12,false}})do
 local host,major,native=table.unpack(case)
 local draws=0
 local function canvas()return {getDimensions=function()return 320,240 end,getWidth=function()return 320 end,getHeight=function()return 240 end,setFilter=function()end}end
 local shot={canvas=canvas()};local target=canvas();local current=nil
 local graphics={getCanvas=function()return current end,setCanvas=function(c)current=c end,getBlendMode=function()return 'alpha','alphamultiply'end,setBlendMode=function()end,setColor=function()end,setShader=function()end,clear=function()end,draw=function(c,x,y,r,sx,sy)draws=draws+1;eq(c,shot.canvas,'source');eq(sy,-1,'preflip')end}
 local env=setmetatable({love={graphics=graphics,system={getOS=function()return host end},getVersion=function()return major end}}, {__index=_G})
 -- Execute the latest release's real renderer methods with inert dependencies.
 env.require=function()return {}end
 local Renderer=assert(load(read(root..'/src/render/Renderer.lua'),'release-renderer','t',env))()
 if not native then Renderer.mirrorsWorldOverride=nil else eq(Renderer.mirrorsWorldOverride(),host=='iOS' and major>=12,'native policy')end
 local mods={OverworldBattle={shot=function()return shot end},Voxel3D={metalRenderer=function()return host=='iOS' or host=='OS X'end},PixelCanvas={new=function()return true,target end}}
 local enabled=true
 local mod={find=function()return {exports={lib={require=function(n)return mods[n]end}}}end,events={on=function()end}}
 env.require=function(n)assert(n=='src.render.Renderer');return Renderer end
 local install=assert(load(read(arg[2] or 'lib/battle_art_111_ios_world_orientation.lua'),'orientation','t',env))()
 local bridge=install(mod,function()return enabled end)
 local r=setmetatable({}, {__index=Renderer})
 r:setWorldOverride(shot.canvas)
 local legacy=not native and host=='iOS' and major>=12
 eq(draws,legacy and 1 or 0,host..' copies');eq(r.worldOverride,legacy and target or shot.canvas,'forwarded canvas');eq(bridge:isActive(),legacy,'activity')
 r:setWorldOverride(shot.canvas);eq(draws,legacy and 2 or 0,'refresh same canvas')
 local unrelated=canvas();r:setWorldOverride(unrelated);eq(r.worldOverride,unrelated,'unrelated override')
 enabled=false;r:setWorldOverride(shot.canvas);eq(r.worldOverride,shot.canvas,'disabled')
 r:setWorldOverride(nil);eq(r.worldOverride,nil,'clear')
 bridge:refresh();eq(draws,legacy and 2 or 0,'idempotent')
end
print('World orientation: '..checks..' checks passed against '..root)
