local checks=0
local function eq(a,b,label)checks=checks+1;assert(a==b,label..': '..tostring(a)..' ~= '..tostring(b))end
for _,provider in ipairs({false,true})do
 local events={};local session={party={{species=451,hp=70,nickname='KEEP',moves={{id=1,pp=20}}},{species=25,hp=30}}}
 local copied,starts,fail={},0,false
 local Bridge={start=function()
  starts=starts+1;for i,m in ipairs(session.party)do copied[i]={species=m.species,hp=m.hp}end
  if fail then error('injected failure')end;return true
 end}
 local Runtime={getSession=function()return session end}
 local env=setmetatable({require=function(name)
  if name=='src.core.game3.battle_bridge'then return Bridge end
  if name=='src.core.game3.runtime'then return Runtime end
  error(name)
 end,package={loaded={['src.core.game3.runtime']=Runtime}}},{__index=_G})
 local mod={find=function(_,id)if provider and id=='1025dex'then return {}end end,
  events={on=function(_,name,fn)events[name]=fn end},log={warn=function()end}}
 local f=assert(io.open('lib/gen3_1025dex_party_guard.lua'));local s=f:read('*a');f:close()
 assert(load(s,'guard','t',env))()(mod)
 eq(Bridge.start(nil,{},{}),true,'battle accepted')
 eq(copied[1].species,provider and 451 or 0,'temporary species')
 eq(copied[1].hp,provider and 70 or 0,'temporary HP')
 eq(session.party[1].species,451,'save species restored')
 eq(session.party[1].hp,70,'save HP restored')
 eq(session.party[1].moves[1].pp,20,'save PP retained')
 if not provider then
  session.party[1]={species=0,hp=0};session.party[2].hp=10
  events['battle.ended']()
  eq(session.party[1].species,451,'writeback restored')
  eq(session.party[1].nickname,'KEEP','name retained')
  eq(session.party[2].hp,10,'native battle damage retained')
  fail=true;eq(pcall(Bridge.start,nil,{},{}),false,'failure propagated')
  eq(session.party[1].species,451,'failure restores save')
  fail=false;session.party[2].hp=0
  local before=starts;eq(Bridge.start(nil,{},{}),nil,'no legal party blocks battle')
  eq(starts,before,'unsafe engine call skipped');eq(session.party[1].hp,70,'blocked battle retains HP')
 end
end
print('PASS: '..checks..' party save-safety checks')
