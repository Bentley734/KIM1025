local f=assert(io.open(arg[1] or 'main.lua'));local source=f:read('*a');f:close()
local checks=0
local function eq(a,b,label)checks=checks+1;assert(a==b,label..': '..tostring(a)..' ~= '..tostring(b))end
local function near(a,b,label)checks=checks+1;assert(math.abs(a-b)<1e-6,label..': '..tostring(a)..' ~= '..tostring(b))end
local function image(w,h)return {getDimensions=function()return w,h end}end
local custom,native=image(80,80),image(48,48)
local sprites,selected,orientation,active,hd=true,true,'portrait',true,true
local dpi,offset=3,0
local draws,nativeCalls={},{}
local mod={exports={_kantoInMotionBattleTrainerFrame=function()if selected then return custom end end}}
local env=setmetatable({mod=mod,BattleState={},unpackCompat=table.unpack,
 battleLiteDirectStageActive=function()return active end,battleLiteOwnsSprites=function()return sprites end,
 hdBattleBackgroundsEnabled=function()return hd end,touchBattleOrientation=function()return orientation end,
 hdArenaImage=function()if hd then return native end end,
 nativeBattlePlacementPx=function()return {sx=dpi,sy=dpi}end,
 battleRecord=function()return nil end,battleSystemEnabled=function()return true end,
 transparentPic=function()return image(1,1)end,
 nativeDrawPicsLayer=function(self,...)nativeCalls[#nativeCalls+1]={...};return 'native' end,
 love={graphics={push=function()end,pop=function()end,setShader=function()end,setColor=function()end,
 draw=function(...)draws[#draws+1]={...}end}}},{__index=_G})
local function compile(first,last,extra)
 local a=assert(source:find(first,1,true));local b=assert(source:find(last,a+1,true))
 return assert(load(source:sub(a,b-1)..(extra or ''),'production trainer intro','t',env))()
end
mod._kantoInMotionFlatTrainerFrame=function()return selected and custom or native end
local draw=compile('  local function drawDirectBattleTrainer(', '  drawDirectBattleSprites = function', '\nreturn drawDirectBattleTrainer')
local battle={game={},showPlayerBack=true,playerBackPic=native,
 picImage=function(_,pic)return pic end,picOffset=function()return offset end}
for _,width in ipairs({390,707,1320,2121})do
 local geo={hd=true,hdScale=width/1920,playerX=604*width/1920,playerY=672*width/1920}
 for _,retina in ipairs({1,2,3})do
  dpi=retina;offset=0;draws={}
  eq(draw(battle,geo,battle.game,width,width*2.17),true,'trainer drawn')
  local d=draws[1];near(d[5],8*geo.hdScale,'trainer follows HD arena scale across DPI')
  near(d[2]+80*d[5]/2,geo.playerX,'trainer centered on player platform')
  near(d[3]+80*d[6],geo.playerY,'trainer grounded on player platform')
  offset=-24;draws={};draw(battle,geo,battle.game,width,width*2.17)
  near(draws[1][2]-d[2],offset*dpi,'native intro slide timing retained')
 end
end
compile('  mod._kantoInMotionFlatTrainerFrame = function', '  local function drawDirectBattleTrainer(')
local resolve=assert(mod._kantoInMotionFlatTrainerFrame)
eq(resolve(battle),custom,'selected trainer resolved')
selected=false;eq(resolve(battle),native,'ROM/default trainer resolved')
selected=true;sprites=false;eq(resolve(battle),native,'sprites OFF native trainer resolved')
for _,flag in ipairs({'safari','demo','fieldCleared'})do
 battle[flag]=true;eq(resolve(battle),nil,'native special phase retained '..flag);battle[flag]=nil
end
battle.showPlayerBack=false;eq(resolve(battle),nil,'trainer hidden after send-out');battle.showPlayerBack=true
orientation=nil;eq(resolve(battle),nil,'desktop keeps original trainer path');orientation='portrait'
active=false;eq(resolve(battle),nil,'external/native stage retains ownership');active=true
hd=false;eq(resolve(battle),nil,'no HD background keeps native trainer');hd=true
compile('        BattleState.drawPicsLayer = function(self, ...)', '\n      end\n\n      -- KIM captures the complete 48-row')
for _,kim in ipairs({false,true})do
 sprites=kim;selected=kim;nativeCalls={};draws={};offset=0
 eq(env.BattleState.drawPicsLayer(battle,0,0,0,nil,true),'native','native enemy pass retained')
 eq(nativeCalls[1][4],'enemy','native player trainer excluded')
 local geo={hd=true,hdScale=.5,playerX=302,playerY=336}
 draw(battle,geo,battle.game,960,2080)
 eq(#draws,1,'exactly one trainer draw')
 eq(draws[1][1],kim and custom or native,'correct trainer art')
 eq(battle.playerBackPic,native,'original trainer picture restored')
end
sprites=false;battle.playerBackPic=nil;nativeCalls={}
eq(env.BattleState.drawPicsLayer(battle,0,0,0,nil,true),'native','missing trainer retains source pass')
eq(nativeCalls[1][4],nil,'missing drawable does not hide source trainer')
print('PASS: '..checks..' trainer intro scale, platform, DPI, slide, provider and single-draw checks')
