-- Legacy test entry point; complete arenas replaced the old backdrop layers.
return dofile('tests/aspect_backgrounds.lua')
