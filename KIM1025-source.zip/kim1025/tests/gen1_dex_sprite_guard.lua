-- Reproduce the 1025Dex Gen 1 pics-layer replacement in either load order.
local guard=assert(loadfile('lib/gen1_battle_sprite_guard.lua'))()
local checks=0
local function eq(a,b,label)checks=checks+1;assert(a==b,label..': '..tostring(a)..' ~= '..tostring(b))end
local originalDex
if arg[1] then
 local f=assert(io.open(arg[1]..'/sprites/main.lua'));local s=f:read('*a'):gsub('\r\n','\n');f:close()
 local a=assert(s:find('  local managedSpecies =',1,true))
 local b=assert(s:find('  -- gen3 (FireRed):',a,true))
 originalDex=s:sub(a,b-1)
end
for _,order in ipairs({'kim-first','dex-first'})do
 local time,direct,owns,available=0,true,true,true
 local blank={blank=true};local captured={};local dexPic={frame=1,dex=true}
 local battle={enemy={sprite={vanilla=true},mon={species='RATTATA'}},player={sprite={vanilla=true},mon={species='BULBASAUR'}}}
 local B={picImage=function(_,image)return image end,
  drawPicsLayer=function(self)
   captured={self:picImage(self.enemy.sprite),self:picImage(self.player.sprite)}
  end}
 setmetatable(battle,{__index=B})
 local function installKim()
  guard({},B,function(sp,side)return {frames=2},'hd',sp,false end,
   function(_,_,side)if available then return {frame=math.floor(time*20)%2+1,side=side}end end,
   function()return owns end,function()return direct end,function()return blank end)
 end
 local function installDex()
  if originalDex then
   local env=setmetatable({mod={log={info=function()end}},require=function()return B end,
    DATA={styleFor=function()return 3 end,playerView=function()return false,false end},
    wantEnabled=function()return true end,monStem=function(mon)return mon.species,false end,
    teraTypeOf=function()end,dynamaxOf=function()end,getBattleFrames=function()return {dexPic},false end,
    frameIndex=function()return 1 end,debugOn=function()return false end,ourFrames={},diag={stats={gen1=0}}},{__index=_G})
   assert(load(originalDex..'\nreturn installGen1','installed 1025Dex Gen 1','t',env))()()
  else
   local inner=B.drawPicsLayer
   B.drawPicsLayer=function(self,...)
    self.enemy.sprite=dexPic;self.player.sprite=dexPic
    return inner(self,...)
   end
  end
 end
 if order=='kim-first'then installKim();installDex()else installDex();installKim()end
 for cycle=0,5 do for phase=0,1 do
  time=cycle*.1+phase*.05+.001
  B.drawPicsLayer(battle)
  eq(captured[1],blank,order..' no enemy native/Dex copy covers HD pass')
  eq(captured[2],blank,order..' no player native/Dex copy covers HD pass')
  direct=false;B.drawPicsLayer(battle)
  eq(captured[1].frame,phase+1,order..' enemy loops despite frozen Dex frame')
  eq(captured[2].frame,phase+1,order..' player loops despite frozen Dex frame')
  direct=true
 end end
 owns=false;B.drawPicsLayer(battle);eq(captured[1],dexPic,'sprites OFF yields to Dex')
 owns=true;available=false;B.drawPicsLayer(battle);eq(captured[1],dexPic,'unavailable KIM art retains fallback')
 available=true;battle.showEnemyTrainer=true;battle.showPlayerBack=true
 B.drawPicsLayer(battle);eq(captured[1],dexPic,'enemy trainer retained');eq(captured[2],dexPic,'player trainer retained')
 battle.showEnemyTrainer=false;battle.showPlayerBack=false;battle.enemySendingOut=true;battle.sendingOut=true
 B.drawPicsLayer(battle);eq(captured[1],dexPic,'enemy send-out retained');eq(captured[2],dexPic,'player ball animation retained')
end
print('PASS: '..checks..' Gen 1 Dex conflict checks'..(originalDex and ' against installed 1025Dex code' or ''))
