-- Run from KIM: texlua tests/dex_compat.lua ../dex
-- Exercises the complete KIM Gen3 bridge and production 1025Dex provider.
local dexRoot=arg[1] or '../dex'
local armarougeSlot=assert(loadfile(dexRoot..'/dex/src/gen3shape.lua'))().slot(936)
local checks=0
local function eq(a,b,why)checks=checks+1;assert(a==b,why..': '..tostring(a)..' ~= '..tostring(b))end
local function read(path)local f=assert(io.open(path));local s=f:read('*a');f:close();return s end
local dexSource=read(dexRoot..'/sprites/main.lua')
local a=assert(dexSource:find('  local function installGen3()',1,true))
local z=assert(dexSource:find('  -- gen2 (Gold): BattleState:pic substitution',a,true))
local ca=assert(dexSource:find('  local function frameIndex(count)',1,true))
local cz=assert(dexSource:find('\n  -- ---------------------------------------------------------------------------',ca,true))
local originalRequire=require
for _,hostOS in ipairs({'Linux','Windows','Android','iOS'})do
for _,order in ipairs({'dex-first','kim-first','standalone'})do
 local nativeSpriteDraw,lastSpriteX
 local tick=0
 local hdEnabled=false
 local battleSprites,fullscreenMenu=true,false
 local ready,reloads,hooks={}, {}, {}
 local draws={}
 local backgroundDraw
 local P={national=function(s)return s==armarougeSlot and 936 or s==283 and 258 or s end,keyName=function(s)return s==armarougeSlot and 'ARMAROUGE' or 'PIKACHU' end,
  frontPic=function(s)return {image={native=true,species=s}}end,
  backPic=function(s)return {image={native=true,species=s}}end,icon=function()return {}end,
  picSpecies=function(s)return s end,speciesOf=function(mon)return mon.species end,
  isShiny=function(mon)return mon.isShiny==true end,
  onReload=function(fn)reloads[#reloads+1]=fn end}
 P.monIcon=function(mon)return P.icon(mon.species)end
 P.dexIcon=function(species)return P.icon(species)end
 P.monFrontPic=function(mon)return P.frontPic(mon.species,0,mon.isShiny)end
 P.monPicSpecies=function(mon)return mon.species end
 P.dexFrontPic=function(s)return P.frontPic(s)end
 local state={player={id=0,species=armarougeSlot,mon={species=armarougeSlot,isShiny=true}},enemy={id=1,species=283,mon={species=283}}}
 local Battle={isActive=function()return true end,getState=function()return state end}
 local presentations={}
 local Anim={present=function(id)
  id=id=='enemy' and 1 or id=='player' and 0 or id
  presentations[id]=presentations[id] or {}
  return presentations[id]
 end,shownBattler=function(_,b)return b end}
 local summaryImage
 local summary={_mon={species=25,isShiny=true},draw=function()summaryImage=P.monFrontPic({species=25,isShiny=true}).image end}
 local nativeElev=0
 local ui={_st=state,bounceOffset=function()return 3 end}
 local coords={front={[25]=8,[283]=5},back={},elev={[25]=0,[283]=0}}
 local centerEnv=setmetatable({PicCoords=coords,SPECIES_CASTFORM=385,
  CASTFORM_FRONT_Y={[0]=17,9,9,8},CASTFORM_BACK_Y={[0]=0,0,0,0},CASTFORM_ELEV={[0]=13,14,13,13},
  is_double=function(st)return st.double==true end,
  live_battler=function(id)return id==0 and state.player or state.enemy,state end,
  castform_form=function(_,b)return b.form or 0 end,shows_ghost=function()return state.ghostBattle==true end,
 },{__index=_G})
 ui.battlerSpriteCenter=assert(load(read('tests/fixtures/gen3_battler_center.lua'),'engine centres','t',centerEnv))()
 ui.draw=function(...)return nativeSpriteDraw(...)end
 ui.castformForm=function(_,b)return b.form or 0 end
 ui.showsGhost=function()return state.ghostBattle==true end
 ui.picArgs=function(b,sp)return sp,P.isShiny(b.mon),b.mon and b.mon.personality end
 Anim.coords=function(_,id)return id==3 and {x=144,y=32} or id%2==1 and {x=176,y=40} or {x=72,y=80}end
 local nativeBgCalls=0
 local Bg={draw=function()nativeBgCalls=nativeBgCalls+1 end}
 local foreground={kind='foreground',getWidth=function()return 240 end,getHeight=function()return 160 end}
 local map={current='FR_ROUTE1'}
 local modules={['src.ui.game3.stack']={fullscreen=function()return fullscreenMenu end},['src.core.game3.pokemon']=P,['src.core.game3.battle.init']=Battle,
  ['src.core.game3.battle.anim']=Anim,['src.core.game3.battle.ui']=ui,
  ['src.core.game3.battle.pic_coords']=coords,['src.core.game3.battle.bg']=Bg,['src.core.game3.map']=map,
  ['src.render.Renderer']={canvas=foreground},['src.ui.game3.summary_menu']=summary,
  ['src.mods.Gen3Compat']={speciesName=function(s)return s==armarougeSlot and 'ARMAROUGE' or s==25 and 'PIKACHU' or s==283 and 'MUDKIP' or s==463 and 'BIDOOF' or s==385 and 'CASTFORM' or nil end},
  ['src.core.game3.mon_anim']={framePic=function()return nil end}}
 local function req(name)if modules[name]then return modules[name]end;error('fixture unavailable: '..name)end
 local graphics=setmetatable({
  newCanvas=function()return {setFilter=function()end}end,
  newImage=function()return {setFilter=function()end}end,
  newQuad=function()return {}end,getCanvas=function()return nil end,
  getDimensions=function()return 240,160 end,
  draw=function(image,x,y,r,sx,sy)draws[#draws+1]=image;lastSpriteX=x; if image.kind=="background" then backgroundDraw={x=x,y=y,sx=sx,sy=sy,w=image:getWidth(),h=image:getHeight()} end end,
 },{__index=function()return function()end end})
 local loveFixture={graphics=graphics,image={newImageData=function()return {}end},
  timer={getTime=function()return tick end},system={getOS=function()return hostOS end}}
 local mod={path='.',generation=3,assets={image=function()return {setFilter=function()end,getDimensions=function()return 32,64 end}end},options={define=function()end,get=function(_,key)if key=='hdBattleBackgrounds' then return hdEnabled end if key=='battleSprites' then return battleSprites end return nil end},
  log={info=function()end,warn=function()end,error=function()end},
  events={on=function(_,event,fn)if event=='game.ready'then ready[#ready+1]=fn end end},
  hooks={wrap=function(_,name,fn)hooks[name]=hooks[name]or{};table.insert(hooks[name],fn)end},exports={},
  _kimAssetProvider={image=function(path)return {kind=path:find('backgrounds') and 'background' or 'sprite',setFilter=function()end,getDimensions=function()return 1,1 end,getWidth=function()return 1920 end,getHeight=function()return 950 end}end},
 }
 local rec='{image="kim.png",width=1,height=1,frames=1,columns=1}'
 function mod:read(path)
  if path=='lib/menu_icons.lua' then return read(path)end
  if path=='data/hd_pokemon_national.lua' then return 'return {[25]={dex=25,front={normal={default='..rec..'},shiny={default='..rec..'}},back={normal={default='..rec..'},shiny={default='..rec..'}}}}'end
  if path=='data/hd_battle_backgrounds.lua'then return read(path)end
  return nil
 end
 local dexLift={}
 local dexEnv=setmetatable({require=req,love=loveFixture,GEN=0,mod={info=function()return {type='file'}end,assets={image=function()return {kind='dexIcon',setFilter=function()end}end},log={warn=function()end}},sheets={},
  FRONT_BOX_GEN3={w=64,h=64},BACK_BOX_GEN3={w=64,h=64},GEN3_MAX_ART_H=64,gen3BattleLiftByImage=dexLift,
  package={loaded=modules},wantEnabled=function()return true end,partyIconsOn=function()return true end,
  animateOn=function()return true end,fpsValue=function()return 10 end,now=function()return tick end,
  resolveStem=function(name)return name end,
  getFramesFor=function(back,shiny,stem)
   local frames={{palette=shiny and 'shiny' or 'normal',side=back and 'back' or 'front',frame=1,stem=stem},
           {palette=shiny and 'shiny' or 'normal',side=back and 'back' or 'front',frame=2,stem=stem}}
   for _,image in ipairs(frames)do dexLift[image]=stem=='ARMAROUGE' and 0 or 14 end
   return frames,false
  end,sheetKey=function()return 'unused'end,
 },{__index=_G})
 local installDex=assert(load(dexSource:sub(ca,cz-1)..dexSource:sub(a,z-1)..'\nreturn installGen3','production Dex','t',dexEnv))()
 local kimEnv=setmetatable({require=req,love=loveFixture,package={loaded=modules}},{__index=_G})
 kimEnv.load=function(chunk,name,mode)return load(chunk,name,mode or 't',kimEnv)end
 kimEnv.loadstring=kimEnv.load
 local installKim=assert(load(read('lib/gen3_frlg.lua'),'complete KIM bridge','t',kimEnv))()
 local position=assert(load(read(dexRoot..'/battle_position.lua'),'production Dex position','t',dexEnv))()
 if order=='dex-first'then installDex();position()end
 installKim(mod)
 if order=='kim-first'then installDex();position()end
 for _,fn in ipairs(ready)do fn()end
 for _,fn in ipairs(reloads)do fn()end
 if order=='standalone'then
  eq(mod.exports.frlgSpriteOwner(),'kim1025','standalone owner')
  eq(P.frontPic(25,0,false).kimBattlePlaceholder,true,'standalone KIM sprite retained')
  eq(P.icon(25)._kantoInMotionMenuIcon,true,'standalone KIM party icon retained')
  local front,back=P.frontPic,P.backPic
  P.frontPic=function(...)return front(...)end
  P.backPic=function(...)return back(...)end
  for _,fn in ipairs(reloads)do fn()end
  battleSprites=false
  eq(P.frontPic(25,0,true).image.native,true,'front provider cycle breaks when sprites off')
  eq(P.backPic(25,0,true).image.native,true,'back provider cycle breaks when sprites off')
  battleSprites=true
 else
  eq(mod.exports.frlgSpriteOwner(),'1025dex',order..' owner')
  eq(mod.exports.frlgProviderInstalled(),false,order..' KIM does not seize provider')
  eq(mod._kantoInMotionMenuIcons,true,order..' complete KIM icon module installed')
  for _,sp in ipairs({25,283,armarougeSlot})do
   eq(P.icon(sp).image.kind,'dexIcon',order..' party icon from Dex')
   eq(P.monIcon({species=sp}).image.kind,'dexIcon',order..' mon icon from Dex')
   eq(P.dexIcon(sp).image.kind,'dexIcon',order..' dex icon from Dex')
  end
  for _,sp in ipairs({25,283,armarougeSlot})do for _,back in ipairs({false,true})do for _,shiny in ipairs({false,true})do
   local provider=back and P.backPic or P.frontPic
   tick=0;local one=provider(sp,0,shiny).image
   tick=.1;local two=provider(sp,0,shiny).image
   eq(one.side,back and 'back' or 'front',order..' correct side')
   eq(one.palette,shiny and 'shiny' or 'normal',order..' correct palette')
   eq(one.frame,1,order..' first frame');eq(two.frame,2,order..' advances frame')
   eq(one.native,nil,order..' no ROM fallback square')
  end end end
  summary.draw();eq(summaryImage.palette,'shiny',order..' summary not blanked')
  for _,fn in ipairs(hooks['render.hud']or{})do fn(function()end,{}, {gameX=0,gameY=0,gameWidth=240,gameHeight=160})end
  eq(#draws,0,order..' no duplicate KIM Pokemon overlay')
  Bg.draw();eq(nativeBgCalls,1,order..' native background fallback intact')
  local playerBefore=ui.bounceOffset('mon',0)
  hdEnabled=true
  for _,sp in ipairs({25,283,463,armarougeSlot})do
   state.enemy={id=1,species=sp,mon={species=sp,isShiny=true}}
   for _,elevation in ipairs({0,9})do
    coords.elev[sp]=elevation
    local base=Anim.coords(state,1)
    local _,cy=ui.battlerSpriteCenter(1,sp,base,0,false)
    eq(cy+32+ui.bounceOffset('mon',1),base.y+32+4-3+3-elevation,order..' enemy ground/hover '..sp)
   end
   coords.elev[sp]=0
  end
  state.enemy={id=1,species=25,mon={species=25}};coords.front[25]=18
  hdEnabled=false;local alreadyAligned=ui.bounceOffset('mon',1)
  hdEnabled=true;eq(ui.bounceOffset('mon',1),alreadyAligned-3,order..' aligned enemy receives only mound trim')
  coords.front[25]=8
  eq(ui.bounceOffset('mon',0),playerBefore,order..' player placement unchanged')
  local baseX=Anim.coords(state,1)
  hdEnabled=false;local nativeX=ui.battlerSpriteCenter(1,25,baseX,0,false)
  hdEnabled=true;local moundX=ui.battlerSpriteCenter(1,25,baseX,0,false)
  eq(moundX,nativeX,hostOS..' exported centre remains native')
  local drawX
  local nativeDrawEnv=setmetatable({Ui=ui,Anim=Anim,Pokemon=P,
   battler_sprite_center=function(_,_,base)return base.x,base.y end,
   shows_ghost=function()return false end,
   pic_args=function(b,sp)return sp,false,0 end,
   BallOpen={setBlendShader=function()return false end,monBlend=function()return nil end},
   love=loveFixture,
  },{__index=_G})
  nativeSpriteDraw=assert(load(read('tests/fixtures/gen3_draw_mon_sprite.lua'),'actual engine sprite draw','t',nativeDrawEnv))()
  Anim.shownBattler=function(_,b)return b end
  hdEnabled=false;ui.draw(state.enemy,baseX,false);local actualNativeX=lastSpriteX
  hdEnabled=true;ui.draw(state.enemy,baseX,false)
  eq(lastSpriteX,actualNativeX+(hostOS=='iOS' and 8 or 4),hostOS..' real native draw shifts enemy pixels')
  eq(Anim.present('enemy').ox,nil,hostOS..' enemy animation state untouched')
  eq(Anim.present(0).ox,nil,hostOS..' player animation state untouched')
  local live=Anim.present('enemy')
  live.visible=false;lastSpriteX=nil;ui.draw(state.enemy,baseX,false)
  eq(lastSpriteX,nil,hostOS..' hidden send-out state respected')
  eq(Anim.present('enemy'),live,hostOS..' presentation retains live identity')
  live.visible=true;ui.draw(state.enemy,baseX,false)
  eq(lastSpriteX,actualNativeX+(hostOS=='iOS' and 8 or 4),hostOS..' send-out becomes visible')
  local savedDraw,savedFront=graphics.draw,P.frontPic
  local realNative=nativeSpriteDraw
  nativeSpriteDraw=function()error('native draw fixture error')end
  eq(pcall(ui.draw,state.enemy,baseX,false),false,hostOS..' native error propagated')
  eq(graphics.draw,savedDraw,hostOS..' draw interception restored after error')
  eq(P.frontPic,savedFront,hostOS..' picture provider restored after error')
  nativeSpriteDraw=realNative
  live.visible=nil

  draws={}
  local playerBase=Anim.coords(state,0)
  hdEnabled=false;local playerX=ui.battlerSpriteCenter(0,25,playerBase,0,false)
  hdEnabled=true;eq(ui.battlerSpriteCenter(0,25,playerBase,0,false),playerX,order..' player horizontal placement unchanged')

  eq(ui.bounceOffset('hb',1),3,order..' HUD bounce unchanged')
  state.double=true;state.battlers={[3]={id=3,species=463,mon={species=463}}}
  local base=Anim.coords(state,3);local _,cy=ui.battlerSpriteCenter(3,463,base,0,false)
  eq(cy+32+ui.bounceOffset('mon',3),base.y+32+4-3+3,order..' doubles retain second enemy depth')
  state.double=false
  state.enemy={id=1,species=463,mon={species=463},expTransform={species=armarougeSlot}}
  base=Anim.coords(state,1);_,cy=ui.battlerSpriteCenter(1,armarougeSlot,base,0,false)
  eq(cy+32+ui.bounceOffset('mon',1),base.y+32+4-3+3,order..' transformed species alignment')
  state.enemy={id=1,species=385,form=1,mon={species=385}}
  _,cy=ui.battlerSpriteCenter(1,385,base,1,false)
  eq(cy+32+ui.bounceOffset('mon',1),base.y+32+4-3+3-14,order..' Castform weather hover retained')
  state.enemy={id=1,species=463,mon={species=463}}
  hdEnabled=false;local originalOffset=ui.bounceOffset('mon',1)
  hdEnabled=true;state.ghostBattle=true
  eq(ui.bounceOffset('mon',1),originalOffset,order..' native ghost preserved');state.ghostBattle=false
  local present=Anim.present;Anim.present=function()return {substitute=true}end
  eq(ui.bounceOffset('mon',1),originalOffset,order..' native substitute preserved');Anim.present=present
  hdEnabled=false;eq(ui.bounceOffset('mon',1),originalOffset,order..' no HD background no correction')
  hdEnabled=true
  Bg.draw();eq(nativeBgCalls,1,order..' authored background retains terrain suppression')
  for _,fn in ipairs(hooks['render.hud']or{})do fn(function()end,{}, {gameX=0,gameY=0,gameWidth=240,gameHeight=160})end
  eq(#draws,2,order..' HD background and native foreground only')
  eq(draws[1].kind,'background',order..' KIM background retained')
  eq(draws[2],foreground,order..' Dex battlers/VFX/HUD composited over background')
  for _,v in ipairs({
   {gameX=0,gameY=0,gameWidth=240,gameHeight=160},
   {gameX=5,gameY=5,gameWidth=1440,gameHeight=960},
   {gameX=80,gameY=12,gameWidth=1920,gameHeight=1080},
   {gameX=0,gameY=300,gameWidth=390,gameHeight=260},
   {gameX=23,gameY=7,gameWidth=721,gameHeight=481},
  })do
   backgroundDraw=nil;draws={}
   for _,fn in ipairs(hooks['render.hud']or{})do fn(function()end,{},v)end
   local d=assert(backgroundDraw)
   eq(d.x<=v.gameX+1e-6,true,order..' background covers left')
   eq(d.y<=v.gameY+1e-6,true,order..' background covers top')
   eq(d.x+d.w*d.sx>=v.gameX+v.gameWidth-1e-6,true,order..' background covers right')
   eq(d.y+d.h*d.sy>=v.gameY+v.gameHeight-1e-6,true,order..' background covers bottom')
  end
  fullscreenMenu=true;draws={}
  for _,fn in ipairs(hooks['render.hud']or{})do fn(function()end,{}, {gameX=0,gameY=0,gameWidth=240,gameHeight=160})end
  eq(#draws,0,order..' full-screen Party/Summary owns frame during battle')
  fullscreenMenu=false
 end
end
end
print(('PASS: %d assertions; complete KIM bridge, both load orders, game.ready/reload, regular/shiny front/back, future species, menu previews, standalone fallback and no duplicate battlers.'):format(checks))
