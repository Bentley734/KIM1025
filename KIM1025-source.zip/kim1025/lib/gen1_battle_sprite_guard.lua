-- Resolve at the last native image seam, after competing pics-layer wrappers.
return function(mod, BattleState, recordFor, proxyFor, ownsSprites, directStage, blankFor, providerFor)
  if type(BattleState.picImage) ~= 'function' or BattleState._kim1025FinalPicGuard then return end
  local native = BattleState.picImage
  BattleState._kim1025FinalPicGuard = native
  BattleState.picImage = function(self, image, ...)
    if image and not self.fieldCleared then
      local side
      if self.enemy and self.enemy.mon and image == self.enemy.sprite
          and not self.showEnemyTrainer and not self.enemySendingOut then side = 'front'
      elseif self.player and self.player.mon and image == self.player.sprite
          and not self.showPlayerBack and not self.sendingOut
          and not self.safari and not self.demo then side = 'back' end
      if side then
        if type(providerFor) == 'function' then
          local provided, managed = providerFor(self, side == 'front' and 'enemy' or 'player', image)
          if managed then
            -- Fullscreen suppression is handled by drawPicsLayer's side filter.
            -- Keep the provider's own image/clock at this seam; never replace
            -- 1025Dex art with a KIM atlas or a cached vanilla snapshot.
            return provided or blankFor()
          end
        end
        if not ownsSprites() then return native(self, image, ...) end
        local mon = (side == 'front' and self.enemy or self.player).mon
        local record, generation, species, shiny = recordFor(mon.species, side, mon)
        local frame = record and proxyFor(record, generation, side,
          shiny and 'shiny' or 'normal', species)
        if frame then
          -- 1025Dex can replace KIM's temporary transparent sprite inside its
          -- own drawPicsLayer. Hide that last native copy while the HD world
          -- owns the battler, otherwise it covers the live KIM animation.
          if directStage() then return blankFor() or frame end
          return frame
        end
      end
    end
    return native(self, image, ...)
  end
end
