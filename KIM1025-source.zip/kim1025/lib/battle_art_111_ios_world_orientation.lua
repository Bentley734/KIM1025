-- Legacy Battle Art world-canvas orientation bridge.
-- Current gen1recomp owns iOS orientation through mirrorsWorldOverride().
-- Applying another pre-flip here inverts the battlefield while UI stays upright.
-- Only older engines without that contract need the compatibility copy.
return function(mod, battleSystemEnabled, _battleArtCompat)
  if not (mod and type(battleSystemEnabled) == "function") then return false end

  local target, targetW, targetH = nil, 0, 0
  local lastTarget = nil
  local logged = false

  local function runtime()
    if type(mod.find) ~= "function" then return nil end
    local ok, handle = pcall(mod.find, mod, "BATTLE_ART_VOXEL_FORK")
    if not ok or not handle then
      ok, handle = pcall(mod.find, "BATTLE_ART_VOXEL_FORK")
    end
    local exports = ok and handle and handle.exports or nil
    local lib = type(exports) == "table" and exports.lib or nil
    if not (type(lib) == "table" and type(lib.require) == "function") then
      return nil
    end
    local okO, OverworldBattle = pcall(lib.require, "OverworldBattle")
    local okV, Voxel3D = pcall(lib.require, "Voxel3D")
    local okP, PixelCanvas = pcall(lib.require, "PixelCanvas")
    if not okO or type(OverworldBattle) ~= "table"
        or not okV or type(Voxel3D) ~= "table"
        or not okP or type(PixelCanvas) ~= "table" then
      return nil
    end
    return OverworldBattle, Voxel3D, PixelCanvas
  end

  local function love12Plus()
    if not (love and type(love.getVersion) == "function") then return false end
    local ok, major = pcall(love.getVersion)
    return ok and type(major) == "number" and major >= 12
  end

  local function affectedApple(Voxel3D)
    if not love12Plus() then return false end
    if Voxel3D and type(Voxel3D.metalRenderer) == "function" then
      local ok, value = pcall(Voxel3D.metalRenderer)
      if ok and value == true then return true end
    end
    -- Fallback for an iOS port whose renderer string differs from the one
    -- Battle Art's detector knows about. This branch is still LÖVE 12+ only.
    local system = love and love.system
    if system and type(system.getOS) == "function" then
      local ok, host = pcall(system.getOS)
      if ok and host == "iOS" then return true end
    end
    return false
  end

  local function liveShot()
    local okKim, kim = pcall(battleSystemEnabled)
    if not (okKim and kim == true) then return nil end
    local OverworldBattle, Voxel3D, PixelCanvas = runtime()
    if not (OverworldBattle and affectedApple(Voxel3D)) then return nil end
    if type(OverworldBattle.shot) ~= "function" then return nil end
    local okShot, shot = pcall(OverworldBattle.shot)
    if not (okShot and type(shot) == "table" and shot.canvas) then return nil end
    return shot, PixelCanvas
  end

  local function ensureTarget(PixelCanvas, w, h)
    if target and targetW == w and targetH == h then return target end
    if not (PixelCanvas and type(PixelCanvas.new) == "function") then return nil end
    local ok, made = PixelCanvas.new(w, h)
    if not (ok and made) then return nil end
    if made.setFilter then pcall(made.setFilter, made, "nearest", "nearest") end
    if target and target.release then pcall(target.release, target) end
    target, targetW, targetH = made, w, h
    lastTarget = nil
    return target
  end

  -- Refresh reused source canvases on every handoff; their contents change.
  local function present(canvas, PixelCanvas)
    if not (canvas and type(canvas.getDimensions) == "function") then
      return canvas
    end
    if canvas == lastTarget then return canvas end

    local okSize, w, h = pcall(canvas.getDimensions, canvas)
    if not (okSize and tonumber(w) and tonumber(h) and w > 0 and h > 0) then
      return canvas
    end
    local out = ensureTarget(PixelCanvas, w, h)
    if not out or out == canvas then return canvas end

    local g = love and love.graphics
    if not g then return canvas end
    local prevCanvas = g.getCanvas and g.getCanvas() or nil
    local prevBlend, prevAlpha = "alpha", "alphamultiply"
    if g.getBlendMode then
      local okBlend, a, b = pcall(g.getBlendMode)
      if okBlend then prevBlend, prevAlpha = a or prevBlend, b or prevAlpha end
    end

    local drew = pcall(function()
      g.setCanvas(out)
      if g.setShader then g.setShader() end
      g.setBlendMode("replace", "premultiplied")
      g.setColor(1, 1, 1, 1)
      g.clear(0, 0, 0, 0)
      g.draw(canvas, 0, h, 0, 1, -1)
    end)

    if prevCanvas then g.setCanvas(prevCanvas) else g.setCanvas() end
    if g.setShader then g.setShader() end
    if g.setBlendMode then pcall(g.setBlendMode, prevBlend, prevAlpha) end
    if g.setColor then g.setColor(1, 1, 1, 1) end

    if drew then
      lastTarget = out
      if not logged and mod.log and type(mod.log.info) == "function" then
        logged = true
        mod.log:info("Battle Art iOS world orientation corrected at worldOverride handoff")
      end
      return out
    end
    return canvas
  end

  local function install()
    local okR, Renderer = pcall(require, "src.render.Renderer")
    if not okR or type(Renderer) ~= "table"
        or type(Renderer.setWorldOverride) ~= "function" then
      return false
    end
    if Renderer._kantoInMotionBattleArtIosWorldOrientationV17 then return true end

    local inner = Renderer.setWorldOverride
    Renderer._kantoInMotionBattleArtIosWorldOrientationV17 = inner
    function Renderer:setWorldOverride(canvas)
      -- Presence, rather than its return value, identifies native ownership:
      -- false also means the engine has deliberately selected an upright path.
      if type(Renderer.mirrorsWorldOverride) ~= "function" then
        local shot, PixelCanvas = liveShot()
        if shot and PixelCanvas and canvas == shot.canvas then
          canvas = present(canvas, PixelCanvas)
        end
      end
      return inner(self, canvas)
    end
    return true
  end

  install()
  if mod.events and type(mod.events.on) == "function" then
    mod.events:on("mods.loaded", function() pcall(install) end)
    mod.events:on("battle.started", function() pcall(install) end)
  end

  local M = {}
  function M:isActive()
    local ok, Renderer = pcall(require, "src.render.Renderer")
    if ok and type(Renderer.mirrorsWorldOverride) == "function" then return false end
    local shot = liveShot()
    return shot ~= nil
  end
  function M:refresh() return install() end
  return M
end
