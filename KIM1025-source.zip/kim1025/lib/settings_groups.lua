-- Presentation-only navigation: keep the engine's option descriptors and saves.
return function(mod)
  local api = {}
  local order = {
    {"pokemon", "POKEMON"}, {"battle", "BATTLE"},
    {"interface", "INTERFACE"}, {"title", "TITLE SCREEN"}, {"advanced", "ADVANCED"},
  }
  local children = {
    battle = {{"general", "GENERAL"}, {"backgrounds", "BACKGROUNDS"},
      {"sizing", "POKEMON / TRAINER SIZE"}, {"shadows", "SHADOWS"},
      {"hud", "HUD"}, {"menus", "MENUS / TEXT"}},
    interface = {{"general", "GENERAL"}, {"appearance", "APPEARANCE"},
      {"fonts", "FONTS / TEXT"}, {"screens", "SCREENS"}, {"controls", "CONTROLS"}},
  }
  local function pathFor(row)
    if row.assetManager then return "assets" end
    local key = row.option and row.option.key or row.id or ""
    key = key:gsub("^kim1025:", ""):gsub("^gen[23]", "")
    key = key:sub(1, 1):lower() .. key:sub(2)
    if key:match("^title") then return "title" end
    if key == "enabled" or key == "animate" or key == "menuIcons"
        or key == "menuSprites" or key == "menuSpriteSource"
        or key == "spriteAnimation" then return "pokemon" end
    if key == "hdBattleBackgrounds" or key == "battleBgMode" then return "battle/backgrounds" end
    if key:match("^battleShadow") then return "battle/shadows" end
    if key:match("^battleHud") then return "battle/hud" end
    if key:match("^battlePlayer") or key:match("^battleEnemy")
        or key:match("^battleTrainer") or key:match("^battle3dPokemon")
        or key:match("^potato") then return "battle/sizing" end
    if key == "battleUiWip" or key:match("^battleUi") or key:match("^battleText")
        or key:match("^battleMove") then return "battle/menus" end
    if key:match("^battle") then return "battle/general" end
    if key:match("^startMenu") or key == "pointerUi" or key == "dragPanels" then
      return "interface/controls"
    end
    if key:find("Font") or key:find("font") or key:find("TextScale") then
      return "interface/fonts"
    end
    if key == "integratedModernUi" then return "interface/general" end
    if key == "dialogueUi" or key == "menuUi" or key == "pokemonUi"
        or key == "managerUi" or key == "hideOriginalUi" or key == "minimalUi" then
      return "interface/screens"
    end
    if key:match("^frame") or key:match("^ui") or key == "theme"
        or key == "density" or key == "layoutStyle" or key:find("Opacity")
        or key == "dialogueUiScale" then return "interface/appearance" end
    return "advanced"
  end
  api.pathFor = pathFor

  -- Works for native ListMenu items and ManagerState option rows alike.
  function api.apply(state, source, kind, initialPath)
    local field, cursor = kind == "list" and "items" or "optionRows",
      kind == "list" and "index" or "cursor"
    local nav = state._kimSettingsNavigation
    if not nav then
      nav = {path = initialPath or "", parents = {}}
      state._kimSettingsNavigation = nav
    end
    nav.source, nav.kind = source, kind
    local function rebuild()
      local rows, path = {}, nav.path
      local specs = path == "" and order or children[path]
      if specs then
        for _, spec in ipairs(specs) do
          local target = path == "" and spec[1] or path .. "/" .. spec[1]
          local found = false
          for _, row in ipairs(nav.source) do
            local rowPath = pathFor(row)
            if rowPath == target or rowPath:sub(1, #target + 1) == target .. "/" then
              found = true; break
            end
          end
          if found then
            rows[#rows + 1] = {id = "__kim_group:" .. target, label = spec[2],
              right = "OPEN", value = function() return "OPEN" end,
              activate = function()
                nav.parents[#nav.parents + 1] = {path = nav.path, cursor = state[cursor], scroll = state.scroll}
                nav.path = target; state[cursor] = 1; state.scroll = 0; rebuild()
              end}
          end
        end
      else
        for _, row in ipairs(nav.source) do
          if pathFor(row) == path then rows[#rows + 1] = row end
        end
      end
      -- Asset downloads stay one press away on the main page.
      if path == "" then
        for _, row in ipairs(nav.source) do
          if row.assetManager then rows[#rows + 1] = row end
        end
      end
      if kind == "list" and not specs and #rows > 0 then
        rows[#rows + 1] = {id = "__kim_reset_section", label = "RESET THIS SECTION", right = "RESET",
          activate = function()
            for _, row in ipairs(nav.source) do
              if pathFor(row) == nav.path and row.option and row.option.default ~= nil then
                api.setOption(state.game, row.option.key, row.option.default)
              end
            end
            if nav.refresh then nav.refresh() else rebuild() end
          end}
      end
      if kind == "list" then
        rows[#rows + 1] = {id = "cancel", label = "BACK", cancel = true}
      end
      local title = "KIM1025"
      if path ~= "" then
        for _, spec in ipairs(order) do
          if spec[1] == path then title = spec[2] end
          for _, child in ipairs(children[spec[1]] or {}) do
            if spec[1] .. "/" .. child[1] == path then title = child[2] end
          end
        end
      end
      state._kimSettingsTitle = title
      state[field] = rows
      state[cursor] = math.max(1, math.min(state[cursor] or 1, #rows))
      state._kimGroupedOptions = kind == "manager"
      if kind == "list" then
        state.title = title
      end
    end
    nav.rebuild = rebuild
    rebuild()
    return state[field]
  end
  function api.back(state)
    local nav = state._kimSettingsNavigation
    if not nav or #nav.parents == 0 then return false end
    local parent = table.remove(nav.parents)
    nav.path = parent.path
    state[nav.kind == "list" and "index" or "cursor"] = parent.cursor
    state.scroll = parent.scroll
    nav.rebuild()
    return true
  end

  local ok, Manager = pcall(require, "src.mods.ManagerState")
  if ok and not Manager._kimSettingsGroupsInstalled then
    Manager._kimSettingsGroupsInstalled = true
    local build, open, back = Manager.buildOptionRows, Manager.openOptions, Manager.goBack
    Manager.buildOptionRows = function(state, manifest, schema)
      local rows = build(state, manifest, schema)
      if manifest.id ~= "kim1025" then return rows end
      return api.apply(state, rows, "manager")
    end
    Manager.openOptions = function(state, manifest, ...)
      state._kimSettingsNavigation = nil
      state._kimGroupedOptions = nil
      return open(state, manifest, ...)
    end
    Manager.goBack = function(state, ...)
      if state.screen == "options" and state.currentMod and state.currentMod.id == "kim1025"
          and api.back(state) then return end
      state._kimSettingsNavigation = nil
      state._kimGroupedOptions = nil
      return back(state, ...)
    end
  end
  mod._kimSettingsGroups = api
  return api
end
