-- A dedicated flat move panel; never crop the native Gen1 TYPE/PP window.
return function(mod)
  local Font = require('src.render.Font')
  local TypeChart = require('src.battle.TypeChart')
  local api = {}
  local function customizer()
    if not (mod and type(mod.find)=='function') then return nil end
    local ok,h=pcall(mod.find,'battleuicustomizer')
    if not ok or not h then ok,h=pcall(mod.find,mod,'battleuicustomizer') end
    local e=ok and h and h.exports
    if type(e)=='table' and type(e.setting)=='function' then return e end
  end
  function api.installSourceGuard(active)
    if not mod then return end
    local function install()
      local ok,B=pcall(require,'src.battle.BattleState')
      if not ok or type(B.drawTextArea)~='function' then return end
      if B.drawTextArea==api.sourceWrapper then return end
      local inner=B.drawTextArea
      local function wrapper(battle,...)
        if battle.phase=='moveSelect' and active(battle) then return end
        return inner(battle,...)
      end
      api.sourceWrapper=wrapper;B.drawTextArea=wrapper
    end
    install()
    if mod.events then
      mod.events:on('mods.loaded',install)
      mod.events:on('game.ready',install)
    end
  end
  function api.layout(rect, dpiX, dpiY)
    dpiX, dpiY = tonumber(dpiX) or 1, tonumber(dpiY) or 1
    if dpiX <= 0 then dpiX=1 end
    if dpiY <= 0 then dpiY=1 end
    -- Frames fill the same rectangle as commands/dialogue. Size text
    -- independently so fitting the 2x2 grid never shrinks the entire panel.
    local scale = math.min(rect.w*dpiX/336, rect.h*dpiY/64)
    return {x=rect.x,y=rect.y,sx=rect.w/336,sy=rect.h/64,
      textSx=scale/dpiX,textSy=scale/dpiY}
  end
  function api.draw(battle, rect, viewport)
    if battle.phase~='moveSelect' then return false end
    local g=love.graphics
    local p=api.layout(rect,viewport and viewport.dpiX,viewport and viewport.dpiY)
    g.push('all')
    local ok,err=pcall(function()
      g.origin();g.setShader();g.setScissor()
      g.translate(p.x,p.y);g.scale(p.sx,p.sy)
      local function text(label,x,y,width)
        label=tostring(label)
        local measured=Font.width and Font.width(label) or #label*8
        local fit=width and math.min(1,width*p.sx/math.max(1,measured*p.textSx)) or 1
        g.push('all');g.translate(x,y)
        g.scale(p.textSx*fit/p.sx,p.textSy*fit/p.sy)
        local drawn,why=pcall(Font.draw,label,0,0);g.pop()
        if not drawn then error(why,0) end
      end
      local function cursor(code,x,y)
        g.push('all');g.translate(x,y)
        g.scale(p.textSx/p.sx,p.textSy/p.sy)
        local drawn,why=pcall(Font.drawCode,code,0,0);g.pop()
        if not drawn then error(why,0) end
      end
      local theme=customizer()
      -- One restrained frame, four distinct move cards and a compact detail rail.
      -- The customizer still controls background opacity; glyphs stay opaque.
      local moves=battle.player and battle.player.curMoves or {}
      local palette={NORMAL={.64,.66,.57},FIRE={.91,.39,.23},WATER={.26,.57,.86},
        ELECTRIC={.91,.72,.20},GRASS={.36,.67,.38},ICE={.39,.75,.78},
        FIGHTING={.78,.34,.29},POISON={.65,.39,.73},GROUND={.73,.57,.34},
        FLYING={.57,.63,.85},PSYCHIC={.87,.39,.60},BUG={.58,.67,.24},
        ROCK={.66,.59,.35},GHOST={.48,.43,.68},DRAGON={.45,.40,.82},
        DARK={.43,.39,.36},STEEL={.57,.65,.70},FAIRY={.84,.54,.72}}
      local selected=moves[battle.moveIndex or 1]
      local selectedDef=selected and battle.data.moves[selected.id]
      local typeName=selectedDef and selectedDef.type and TypeChart.displayName(selectedDef.type,battle.data) or '--'
      local accent=palette[tostring(typeName):upper()] or {.36,.65,.64}
      local function fill(r,gc,b,a,x,y,w,h)
        g.setColor(r,gc,b,a);g.rectangle('fill',x,y,w,h)
      end
      local function frames()
        fill(.08,.14,.16,1,0,0,336,64)
        fill(.83,.88,.80,1,2,2,332,60)
        fill(.96,.97,.88,1,3,3,330,58)
        fill(.84,.90,.84,1,240,3,93,58)
        fill(accent[1],accent[2],accent[3],1,240,3,3,58)
        for i=1,4 do
          local col=(i-1)%2;local row=math.floor((i-1)/2)
          local x,y=6+col*116,6+row*27
          local active=battle.moveIndex==i
          fill(.74,.79,.71,1,x,y+1,112,25)
          if active then
            fill(.78,.88,.80,1,x,y,112,24)
            fill(.18,.43,.38,1,x,y,3,24)
          else fill(.91,.94,.85,1,x,y,112,24) end
        end
        fill(.28,.39,.38,1,248,29,80,1)
        local maximum=selectedDef and (tonumber(selected.maxPp) or (tonumber(selectedDef.pp) or 0)+(selected.ppUps or 0)*math.floor((tonumber(selectedDef.pp) or 0)/5)) or 0
        local ratio=maximum>0 and math.max(0,math.min(1,(tonumber(selected.pp) or 0)/maximum)) or 0
        fill(.28,.39,.38,1,248,25,80,2)
        fill(accent[1],accent[2],accent[3],1,248,25,80*ratio,2)
      end
      if theme and type(theme.faded)=='function' then theme.faded(frames) else frames() end
      -- Keep the selection visible even with highly transparent backgrounds.
      local index=math.max(1,math.min(4,battle.moveIndex or 1))
      local cx,cy=6+((index-1)%2)*116,6+math.floor((index-1)/2)*27
      fill(.85,.95,.88,.55,cx,cy,112,24)
      fill(.12,.39,.32,1,cx,cy,3,24)
      fill(.12,.25,.23,.75,0,0,336,1)
      fill(.12,.25,.23,.75,0,63,336,1)
      g.setColor(.08,.16,.15,1)
      local moves=battle.player and battle.player.curMoves or {}
      for i=1,4 do
        local col=(i-1)%2;local row=math.floor((i-1)/2)
        local x,y=16+col*116,14+row*27
        local mv=moves[i];local def=mv and battle.data.moves[mv.id]
        text(def and def.name or mv and tostring(mv.id) or '-',x,y,104)
        if battle.moveIndex==i then cursor(0xED,x-9,y) end
        if battle.moveSwapIndex==i and battle.moveIndex~=i then cursor(0xEC,x-9,y) end
      end
      local selected=moves[battle.moveIndex or 1]
      local def=selected and battle.data.moves[selected.id]
      g.setColor(.08,.16,.15,1)
      text('PP',248,14,24)
      local pp='--/--'
      if def then
        local base=tonumber(def.pp) or 0
        local maximum=tonumber(selected.maxPp) or base+(selected.ppUps or 0)*math.floor(base/5)
        pp=string.format('%d/%d',tonumber(selected.pp) or 0,maximum)
      end
      text(pp,328-#pp*8,14,#pp*8)
      text('TYPE',248,34,80)
      local name=def and def.type and TypeChart.displayName(def.type,battle.data) or '--'
      -- The native pixel font is eight pixels wide. Long type names get a
      -- separate line, keeping the detail column legible without stretching.
      text(name,248,46,80)
      if battle.player and battle.player.disabledSlot==battle.moveIndex then
        text('DISABLED',248,24,80)
      end
    end)
    g.pop()
    if not ok then error(err,0) end
    return true
  end
  return api
end
