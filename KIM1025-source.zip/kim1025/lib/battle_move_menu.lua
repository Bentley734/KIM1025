-- A dedicated flat move panel; never crop the native Gen1 TYPE/PP window.
return function(mod)
  local Font = require('src.render.Font')
  local TypeChart = require('src.battle.TypeChart')
  local api = {}
  local function customizer()
    if not (mod and type(mod.find)=='function') then return nil end
    local ok,h=pcall(mod.find,'battleuicustomizer')
    if not ok or not h then ok,h=pcall(mod.find,mod,'battleuicustomizer') end
    local e=ok and h and h.exports
    if type(e)=='table' and type(e.setting)=='function' then return e end
  end
  function api.installSourceGuard(active)
    if not mod then return end
    local function install()
      local ok,B=pcall(require,'src.battle.BattleState')
      if not ok or type(B.drawTextArea)~='function' then return end
      if B.drawTextArea==api.sourceWrapper then return end
      local inner=B.drawTextArea
      local function wrapper(battle,...)
        if battle.phase=='moveSelect' and active(battle) then return end
        return inner(battle,...)
      end
      api.sourceWrapper=wrapper;B.drawTextArea=wrapper
    end
    install()
    if mod.events then
      mod.events:on('mods.loaded',install)
      mod.events:on('game.ready',install)
    end
  end
  function api.layout(rect, dpiX, dpiY)
    dpiX, dpiY = tonumber(dpiX) or 1, tonumber(dpiY) or 1
    if dpiX <= 0 then dpiX=1 end
    if dpiY <= 0 then dpiY=1 end
    local scale = math.min(rect.w*dpiX/336, rect.h*dpiY/64)
    if scale >= 1 then scale=math.floor(scale) end
    return {x=rect.x+(rect.w-336*scale/dpiX)/2,
      y=rect.y+rect.h-64*scale/dpiY, sx=scale/dpiX,sy=scale/dpiY}
  end
  function api.draw(battle, rect, viewport)
    if battle.phase~='moveSelect' then return false end
    local g=love.graphics
    local p=api.layout(rect,viewport and viewport.dpiX,viewport and viewport.dpiY)
    g.push('all')
    local ok,err=pcall(function()
      g.origin();g.setShader();g.setScissor()
      g.translate(p.x,p.y);g.scale(p.sx,p.sy)
      local function panel(x,w)
        g.setColor(0.14,0.19,0.22,1);g.rectangle('fill',x,0,w,64)
        g.setColor(0.67,0.35,0.26,1);g.rectangle('fill',x+2,2,w-4,60)
        g.setColor(0.86,0.89,0.79,1);g.rectangle('fill',x+5,5,w-10,54)
      end
      local theme=customizer()
      local function frames()
        if theme and theme.setting('style',1)==2 and type(theme.panel)=='function' then
          theme.panel(0,0,240,64,false);theme.panel(240,0,96,64,false)
        else
          panel(0,240);panel(240,96)
        end
      end
      -- Customizer composites opacity once and leaves text at full opacity.
      -- Its panel export also reuses imported Emerald artwork when available.
      if theme and type(theme.faded)=='function' then theme.faded(frames) else frames() end
      g.setColor(0.08,0.10,0.12,1)
      local moves=battle.player and battle.player.curMoves or {}
      for i=1,4 do
        local col=(i-1)%2;local row=math.floor((i-1)/2)
        local x,y=16+col*112,14+row*26
        local mv=moves[i];local def=mv and battle.data.moves[mv.id]
        Font.draw(def and def.name or mv and tostring(mv.id) or '-',x,y)
        if battle.moveIndex==i then Font.drawCode(0xED,x-9,y) end
        if battle.moveSwapIndex==i and battle.moveIndex~=i then Font.drawCode(0xEC,x-9,y) end
      end
      local selected=moves[battle.moveIndex or 1]
      local def=selected and battle.data.moves[selected.id]
      Font.draw('PP',248,14)
      local pp='--/--'
      if def then
        local base=tonumber(def.pp) or 0
        local maximum=tonumber(selected.maxPp) or base+(selected.ppUps or 0)*math.floor(base/5)
        pp=string.format('%d/%d',tonumber(selected.pp) or 0,maximum)
      end
      Font.draw(pp,328-#pp*8,14)
      Font.draw('TYPE/',248,34)
      local name=def and def.type and TypeChart.displayName(def.type,battle.data) or '--'
      -- The native pixel font is eight pixels wide. Long type names get a
      -- separate line, keeping the detail column legible without stretching.
      Font.draw(name,248,46)
      if battle.player and battle.player.disabledSlot==battle.moveIndex then
        Font.draw('DISABLED',248,24)
      end
    end)
    g.pop()
    if not ok then error(err,0) end
    return true
  end
  return api
end
