## 1.7.4 — Downloader selector and Gen 1 battle animation

The KIM ASSETS downloader now draws a visible selection arrow beside the selected download or removal option, independent of the game's font.

Red/Blue/Yellow battle constructors receive HD Pokemon art as soon as its assets are available. Native battle draws use an immutable image for each animation frame so image-processing caches cannot freeze a reused canvas; the fullscreen HD pass uses the same frame-safe presentation. Animation continues across repeated loops. Missing assets retain vanilla fallback, and ANIMATION OFF still holds the first frame.

Install `kim1025-1.7.4.zip` (about 9 MB), replace the installed `mods/kim1025` folder, keep the downloaded asset cache, and restart. The existing KIM1025 artwork pack remains version 1.0.0, served from release v1.7.3; installed artwork does not need another download.

Validation: 17 runnable regression suites passed; 86 Lua files compiled. Includes 930 downloader checks and 73 battle constructor/animation checks. The installed Mac LOVE runtime passed 28 GPU checks for selector positioning and repeated animation through an image-processing cache. Full ROM and physical phone gameplay remain unverified.

## 1.7.3 — Persistent in-app KIM1025 assets

The installable mod ZIP is now about 9 MB. The 216 portrait, widescreen and ultrawide battle backgrounds live in an independently versioned KIM1025 artwork pack, downloaded once into the persistent mod cache. Future code updates retain this cache and do not require another 400+ MB download.

Open KIM ASSETS in the main KIM asset downloader. DOWNLOAD ALL installs missing original KIM packs, then KIM1025 assets. DOWNLOAD KIM1025 installs only the new artwork pack. Users with original KIM assets already installed are prompted for KIM1025 assets after updating. B defers the prompt; the download remains available in KIM ASSETS. Existing packaged artwork can migrate locally when upgrading in place; a clean small mod installation downloads the artwork.

Install `kim1025-1.7.3.zip`, close the game, replace `mods/kim1025` with its extracted `kim1025` folder, retain the downloaded asset cache, and restart. Accept the in-app download prompt. `KIM1025-assets-v1.0.0.zip` is an artwork pack used by the downloader, not an installable mod ZIP. Pack version 1.0.0 remains independent of code version 1.7.3. Keep release v1.7.3 and its asset ZIP available for future clients.

Each downloaded artwork file is SHA-256 checked before installation. Completion is recorded only after extraction and metadata/index writes succeed. Original KIM and KIM1025 packs use separate cache namespaces and separate removal indexes. Cancelling an asset download defers missing packs, and retry resumes the failing pack without restarting installed original packs. The existing portable and mobile download paths are reused.

Validation: all 17 runnable headless suites pass and 86 Lua files compile, including 426 hub-flow checks and 90 production ZIP/cache checks. Full-pack validation in the installed Mac LÖVE runtime passed 12 checks, verified all 216 real artwork hashes, and decoded portrait, widescreen and ultrawide art. Full ROM and physical phone gameplay remain unverified.

# KIM1025 1.7.2

Fixes small or misplaced player trainers in mobile HD battle intros. Trainers now draw once, at the authored player platform, at a readable size that scales with the arena rather than the native UI. ROM/default trainer art and BATTLE SPRITES OFF use the same alignment. Native slide timing, animation, desktop presentation, Safari/demo scenes, and external stage ownership are preserved.

Includes the v1.7.1 player Pokemon animation fix and all supporting libraries, data, and packaged artwork.

Install the complete KIM1025-v1.7.2.zip: close the game, replace mods/kim1025 with its extracted kim1025 folder, retain the external downloaded asset cache, and restart. Avoid a nested kim1025/kim1025 folder. The small hotfix is an overlay: merge into an existing full installation and keep assets.

Validation: 15 runnable headless suites pass, including 82 trainer-intro checks; 83 Lua files compile. The previous build reproduces the trainer scale failure. The installed Mac game's LÖVE runtime rendered the production trainer code and actual art in an isolated test scene at 1320x2868 and 660x1434; 9 GPU checks pass and visible trainer contact is within one pixel of the platform anchor. This was a renderer fixture, not a full ROM gameplay test or physical iPhone test.

---

## 1.7.1

- Fix Gen 1/2 native battle sprite canvases inheriting the player-slot clip rectangle, which could prevent new animation frames from reaching cached sprites.
- Fix the Gen 2 virtual battle sprite path decoder and define its renderer before the refresh callback uses it.
- Give cooperating battle scenes immutable HD canvases per frame so image preprocessing caches do not freeze player or enemy animation.
- Add 44 headless regression checks for player frame advancement, Gen 2 bridge resolution, scene caching, preserved clipping, and animation/sprite toggles.

## 1.7.0

- Gen 3 Start Menu → KIM1025 opens the complete native settings page. UI SETTINGS and BATTLE SETTINGS expose the complete schema, including player/enemy size. OPTIONS also retains KIM1025 and ASSETS access; OPTIONS → MODS → KIM1025 uses the expanded registered schema.
- Gen 3 HD backgrounds can use KIM1025's packaged complete arenas when the external PNG pack is absent. Embedded platform coordinates are respected. HD BATTLE BACKGROUNDS OFF restores the native field. Hoenn environments without suitable art retain their native scenes.
- Adds upstream Gen 3 Modern menus, dialogue, naming, Trainer Card, storage, Summary, Pokédex and lower battle panels, readability fixes and controller navigation improvements.
- Adds cooperative 1025Dex routing: supported #001–386 HD art uses KIM, expanded species retain the Dex art provider. Missing HD files fall back safely. Turning BATTLE SPRITES off restores the provider.
- Adds upstream Unown/Deoxys form metadata, layered asset upgrades, Gen 2 Summary and Battle Art compatibility, and responsive UI fixes.
- Preserves the kim1025 mod ID, existing settings/cache ownership, custom portrait/widescreen/ultrawide arenas, Gen 1 sizing controls and mobile/iOS corrections. General UI font scale now follows upstream's 200% cap.


## 1.6.31

- Add 72 location-specific complete 32:9 arenas with blended scenery and preserved original mound coordinates.
- Automatically select ultrawide images at viewport ratios of 3:1 or wider.
- Prevent inherited native-menu scissor clipping from leaving side bars.
- Add 3840×1080, 5120×1440 and 7680×2160 coverage and alignment regressions.

## 1.6.30

- Replace layered portrait/widescreen backdrops with 144 complete, location-specific HD arenas.
- Composite the original mound regions at fixed coordinates, preserving existing Pokémon alignment.
- Remove the backdrop blend shader and retain a single active arena texture.
- Validate all 72 scenes, platform renderer paths, image decoding and existing generation bridges.

## 1.6.26

- Fix the Gen 1 fullscreen enemy draw calculation to read ENEMY PKMN SIZE, including native/1025Dex art when KIM sprites are disabled.
- Correct outdoor power-plant exterior, Mt. Moon and Silph Co extension family mappings.
- Draw extensions in mobile landscape as well as portrait.
- Align native/Dex sprites to the HD arena in landscape and remove the desktop player vertical compensation on mobile.
- Verify actual Gen 1 draw scales at 50%, 100%, 150% and 200% with both art providers and orientations.

## 1.6.25

- Register PLAYER PKMN SIZE and ENEMY PKMN SIZE in the standalone FireRed/LeafGreen bridge, which returns before the Gen 1 option schema is loaded.
- Add the enemy-size row to all Modern UI category maps so the saved value is exposed and read correctly on desktop and mobile.

## 1.6.24

- Fix ENEMY PKMN SIZE being bypassed by the fullscreen/native handoff scale seam.
- Apply the enemy multiplier before native source sprites are suppressed, so the setting remains effective across KIM fullscreen and fallback battle paths.

## 1.6.23

- Add ENEMY PKMN SIZE with the same 50%–200% range and 5% steps as PLAYER PKMN SIZE.
- Apply the enemy multiplier consistently to fullscreen KIM battles, FR/LG battle rendering, cooperative staged scenes and Battle Art 3D presentations.
- Keep the calibrated 100% enemy presentation unchanged.

## 1.6.22

- Fix portrait extension mismatches by deriving the extension from the exact backdrop selected for the original battle image.
- Prevent field battles from receiving unrelated industrial/interior scenery when the router state changes between lookups.

## 1.6.21

- Add generated portrait extension layers for every current HD battle-background family.
- Keep the original landscape art as an unchanged middle band so platforms, sprites and HUD anchors do not move.
- Tint only the extension for night, sunrise and sunset variants; preserve the original variant artwork exactly.

## 1.6.20

- Keep portrait AUTO backgrounds at full battlefield width when KIM battle sprites are disabled.
- Apply portrait platform alignment and duplicate-source suppression to the active native/1025Dex sprite provider with KIM sprites OFF.
- Preserve explicit NATIVE FIT, desktop/landscape AUTO behavior, and the iOS orientation fix.

## 1.6.19

- Align mobile portrait fallback battlers with the authored HD platforms instead of the centered native battle slots.
- Keep one visible fallback sprite and preserve its active provider, including 1025Dex art.
- Remove the desktop-only player ground compensation from portrait scenes; retain the iOS orientation fix.

## 1.6.18

- Fix the KIM-owned flat HD battle scene on iOS: compose this top-origin canvas upright instead of applying the voxel pipeline's vertical mirror.
- Keep orientation local to the marked flat canvas during final composition; preserve other providers, animations and overlay coordinates.

## 1.6.17

- Fix upside-down iOS Battle Art scenes by deferring world orientation to current gen1recomp.
- Restrict the legacy correction to Battle Art's actual canvas and refresh moving scenes every frame.

# Changelog

## Compat v1.6.15 — Fix duplicate battles in narrow desktop windows

- Use the single flat battle presenter in portrait desktop windows as well as native mobile.
- Replay native trainers, Pokemon, effects and HUD from the canvas used by that presenter.
- Keep landscape desktop presentation and existing mobile positioning.

## Compat v1.6.14 — Halve iOS enemy offset

- Reduce iOS horizontal trim from sixteen to eight native game pixels.
- Preserve the sprite visibility fix and other platform positioning.

## Compat v1.6.13 — Restore sprite visibility

- Remove the animation-state copying hook that broke live visibility updates.
- Apply horizontal trim only while native front-picture pixels are drawn.
- Restore temporary providers/graphics interception after success or error.
- Test mutable presentation state, hidden-to-visible transitions and actual draw coordinates.

## Compat v1.6.12 — Apply horizontal trim in the actual draw path

- Replace the ineffective exported sprite-centre hook with a copied presentation offset.
- Preserve cached animation state and avoid double-shifting KIM cards.
- Add a regression exercising the actual native sprite draw, not only its exported helper.

## Compat v1.6.11 — Increase iOS enemy horizontal trim

- Move iOS HD-background enemies another eight native game pixels right.
- Preserve other platforms and all vertical placement.

## Compat v1.6.10 — iOS enemy horizontal trim

- Add four extra native pixels right on iOS HD battle backgrounds only.
- Preserve desktop/Android placement, enemy height and player alignment.
- Exercise the compositor on Linux, Windows, Android and iOS platform fixtures.

## Compat v1.6.9 — Enemy mound placement

- Nudge HD-background enemies four native pixels right and three up.
- Retain Dex ground correction, hover/elevation, animation and player placement.

## Compat v1.6.8 — OPTION / ASSETS

- Move asset management from Start/title menus to OPTION and rename the row ASSETS.
- Native Gen3 uses an A-only action with B returning to the existing OPTION layer.
- Preserve downloads, maintenance, sprite compatibility and background filling.

## Compat v1.6.7 — HD background viewport coverage

- Ensure FR/LG HD battle backgrounds cover every edge of the fitted battle viewport at any screen size or orientation. Expand whole image axes only where needed and clamp framing to available overscan.
- Preserve native battler, HUD, particle and menu coordinates and 1025Dex ownership.
- 239 sprite/compositor checks and 326 asset-manager checks pass.

## Compat v1.6.6 — Merge upstream 1.6.2

- Merge all upstream 1.6.2 asset-management, portable/mobile download, Party/Summary,
  Gen2 menu and iOS Battle Art changes.
- Preserve 1025Dex picture/icon ownership, shiny animation and enemy ground alignment.
- Retain explicit readable native text colours and protected graphics state in
  the new native asset-manager host.

## Upstream v1.6.2

- Added HD Asset Manager removal/re-download support for the persistent external HD Pokémon/background cache. Removed assets can be downloaded again immediately or later; KIM does not force a new download after removal.
- Added Gen1Recomp portable-mode Asset Manager support using the engine's binary-safe downloader and native temporary-file handoff while keeping final assets in portable-aware `mod.cache`.
- Added a native FireRed/LeafGreen **KIM ASSETS** Start Menu entry for downloading, removing, and re-downloading the shared HD pack.
- Fixed Android/iOS FR/LG asset downloads by reopening the engine-owned temporary ZIP through Gen1Recomp's native save-directory helper before extraction.
- Corrected FR/LG installed-pack controls to **A = REMOVE / B = CLOSE**, with a second **A** confirmation before deletion.
- Fixed Gold/Silver/Crystal mobile lookup of downloaded National Dex #152–251 HD assets so the external pack is actually used after a successful download.
- Fixed FR/LG in-battle Party/Summary presentation so KIM's battle compositor no longer overwrites final-resolution HD menu Pokémon/icons while a full-screen Game3 menu owns the frame.
- Added a KIM-side FR/LG provider-cycle guard for GameShark when **BATTLE SPRITES = OFF**, preventing recursive native-sprite delegation without changing GameShark.
- Fixed the Gen 2 Modern Start Menu at larger UI scales/densities so the selected native row always remains visible, including **MODS** and **QUIT**.
- Reworked the iOS/LÖVE 12 Battle Art orientation bridge at the final world handoff. The correction follows Battle Art's live 3D world directly, uses Battle Art-compatible canvas handling, and leaves KIM HUD/UI/touch layers unflipped.

## v1.6.5 — Enemy ground alignment with 1025Dex

- Compensate Dex small-picture lift and native front-picture padding while KIM HD backgrounds are active.
- Preserve enemy hover, doubles layout, transforms, animation and native bounce.
- Keep player placement, ghost/substitute and non-HD battles unchanged.

## v1.6.4 — Visible Gen3 asset installer

- Draw asset-manager text through Gen3 Window.printPx with explicit dark colours.
- Use a native 240x160 window and isolate shader/scissor/blend state while drawing.
- Defer Gen3 party/PC/Pokedex icon providers and the HD icon replay overlay to 1025Dex.
- Preserve native stack controls, asset downloads and 1025Dex sprite compatibility.

## v1.6.3 — Gen3 asset manager

- Open the KIM HD asset installer through the native Gen3 singleton screen stack.
- Route update, input, draw and close through the correct Gen3 layer methods.
- Give the KIM ASSETS row a stable id and handle selection on older Gen3 menus.
- Retain the 1025Dex sprite compatibility from v1.6.2.

## Compat v1.6.2 — 1025Dex compatibility

- Detect 1025Dex v1.2.5 sprite ownership on Gen3 startup and reload.
- Preserve Dex animated front/back sprites, shiny palettes and height metadata.
- Skip competing HD battler/menu preview overlays while Dex owns pictures.
- Retain KIM HD backgrounds, native foreground/VFX/HUD and standalone sprite behavior.

## v1.6.1

- Hardened Gen 1 Android/mobile battle rendering against graphics-state leaks that could accumulate into `Maximum stack depth reached`.
- Decoupled the Gen 1 Modern battle dialog/command layout from virtual TouchControls visibility so controller-equipped Android devices keep the lower battle UI with touch controls hidden.
- Restored the first Oak's Lab rival intro using KIM's packaged `garyfrontplayer` art at the corrected mobile scale and suppressed the duplicate native rival image during the outro.
- Expanded Gen 1 NEW GAME Modern UI coverage while keeping Oak's native intro artwork/timing and source game state ownership intact.
- Added KIM Modern UI presentation for the initial Gen 1 `WHICH PC?` menu while preserving native PC rows, callbacks, Player PC, and Bill's PC behavior.
- Added a narrowly scoped iOS Battle Art world-orientation compatibility bridge for the affected Apple/Metal renderer, based on Battle Art's current world-canvas correction strategy. KIM HUD/UI layers remain unflipped.
- Preserved native presentation when Modern UI or the applicable per-surface setting is disabled.
- Gen 2/Crystal and Gen 3/FireRed-LeafGreen battle paths remain unchanged by the Gen 1 mobile fixes.

## v1.6.0

- Split large HD battle artwork from the normal KIM ZIP and added the in-game HD Asset Manager with persistent caching.
- Moved the large HD battle asset pack to persistent external cache so users download it once on v1.6.0 and reuse it across future KIM updates.
- Expanded Gen 2 Modern UI to the title/main menu and complete NEW GAME setup flow.
- Fixed Gen 2 Modern UI master/per-surface gating and removed the stray MAPA Start Menu row.
- Added presentation-only Dex Radar 1.2.0 compatibility on Gen 1 and Gen 2 without modifying Dex Radar.
- Added Gen 1 BATTLE BG MODE with AUTO / FULLSCREEN / NATIVE FIT framing for HD or vanilla battlers.
- Corrected Gen 1 widened-field trainer placement/size, enemy move-side animation ownership, and lingering KRBA BG/FG planes.
- Improved FR/LG missing-HD fallback and BATTLE SPRITES OFF stability.
- Restored the small local battle-support/trainer assets required by the slim core.

## v1.5.0

- Added Gold / Silver / Crystal and FireRed / LeafGreen support paths.
- Added HD animated Pokémon support through #251 in G/S/C and #386 in FR/LG.
- Added HD Pokémon icons #001–386 across all supported games.
- Added `POKEMON ICONS` ON/OFF control.
- Added G/S/C native-battle HD Pokémon integration.
- Added FR/LG HD battles, menu/Pokédex/Summary previews, and HD battle-background support.
- Added final-resolution G/S/C and FR/LG menu rendering.
- Fixed FR/LG mobile duplicate HUD/menu rendering, portrait/landscape placement, `SCREEN POS`, and menu Pokémon alignment.
- Improved HGSS_SPRITES icon ownership and Gen 1 battle isolation.
- Preserved existing Gen 1 Battle Art and PotatoVoxel compatibility.

## v1.4.1

- Added Gen1Recomp 0.3.1 compatibility.
- Added HGSS_SPRITES Gen 1 battle hard block.
- Preserved Battle Art and PotatoVoxel compatibility.

## v1.4.0

- Public Gen 1 HD battle release.
- Added the Gen 1 HD animated Pokémon battle pipeline and HD battle backgrounds.
