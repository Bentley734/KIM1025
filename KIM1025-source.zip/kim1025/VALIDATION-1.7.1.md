# KIM1025 1.7.1 validation

The new production-function regression test reproduced a player sprite frame failure before the fix: an inherited native scissor prevented the cached player canvas from receiving its first frame.

After the fix, 44 checks passed for Gen 1/2 native cached sprite advancement, front/back virtual path routing, frame-specific scene drawables, restoration of host clipping, ANIMATION OFF, and BATTLE SPRITES OFF.

All 14 runnable headless test files passed, including Gen 3 settings/background/save regressions and the real Gen 1 draw/alignment fixtures. All 82 Lua files compiled. The production 1025Dex integration test still requires the separate unavailable source checkout. No live graphical playthrough was performed.
