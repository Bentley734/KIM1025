## 1.7.3 — Persistent in-app KIM1025 assets

The installable mod ZIP is now about 9 MB. The 216 portrait, widescreen and ultrawide battle backgrounds live in an independently versioned KIM1025 artwork pack, downloaded once into the persistent mod cache. Future code updates retain this cache and do not require another 400+ MB download.

Open KIM ASSETS in the main KIM asset downloader. DOWNLOAD ALL installs missing original KIM packs, then KIM1025 assets. DOWNLOAD KIM1025 installs only the new artwork pack. Users with original KIM assets already installed are prompted for KIM1025 assets after updating. B defers the prompt; the download remains available in KIM ASSETS. Existing packaged artwork can migrate locally when upgrading in place; a clean small mod installation downloads the artwork.

Install `kim1025-1.7.3.zip`, close the game, replace `mods/kim1025` with its extracted `kim1025` folder, retain the downloaded asset cache, and restart. Accept the in-app download prompt. `KIM1025-assets-v1.0.0.zip` is an artwork pack used by the downloader, not an installable mod ZIP. Pack version 1.0.0 remains independent of code version 1.7.3. Keep release v1.7.3 and its asset ZIP available for future clients.

Each downloaded artwork file is SHA-256 checked before installation. Completion is recorded only after extraction and metadata/index writes succeed. Original KIM and KIM1025 packs use separate cache namespaces and separate removal indexes. Cancelling an asset download defers missing packs, and retry resumes the failing pack without restarting installed original packs. The existing portable and mobile download paths are reused.

Validation: all 17 runnable headless suites pass and 86 Lua files compile, including 426 hub-flow checks and 90 production ZIP/cache checks. Full-pack validation in the installed Mac LÖVE runtime passed 12 checks, verified all 216 real artwork hashes, and decoded portrait, widescreen and ultrawide art. Full ROM and physical phone gameplay remain unverified.

