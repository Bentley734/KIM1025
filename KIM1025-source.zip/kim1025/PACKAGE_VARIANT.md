# KIM1025 1.7.0 compatibility fork

Based on KIM1025 1.6.31 and Kanto in Motion 1.7.0, with packaged aspect arenas and kim1025 settings/cache ownership preserved. See RELEASE_NOTES.md and VALIDATION-1.7.0.md.
