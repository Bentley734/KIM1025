# KIM1025 1.6.26 mobile battle fixes

Replace the previous KIM1025 installation and fully restart. Keep one installed version.

Gen 1 fullscreen enemy metrics now read ENEMY PKMN SIZE directly. Earlier 1.6.23–1.6.25 builds omitted this calculation. At 200%, the final draw scale is twice the calibrated 100% scale. Pokemon remain bottom-centered on the same ground anchor. Native/1025Dex art and KIM art use this calculation.

Route 10's power_plant_exterior variants now select the outdoor field extension rather than an industrial interior. Mt. Moon selects cave scenery and Silph Co selects lab scenery. Both phone orientations draw the extension under the original image. The original background transform is preserved. Mobile landscape native/Dex battlers now use the authored arena anchors, and the player no longer receives the desktop 60-pixel downward compensation. Mobile AUTO uses fullscreen framing with either sprite provider; explicit NATIVE FIT stays available.

Current checks: 150 alignment and actual Gen 1 draw assertions, 253 background mapping/asset assertions, and 106 checks using the production flat producer and gen1recomp v0.3.68 Renderer:endFrame. The draw test checks 50%, 100%, 150% and 200% for KIM and native/Dex images in both orientations. Also passing: 73 world orientation, 174 presenter, 134 Hoenn background, 10 Hoenn bridge and 339 asset manager assertions. These are headless fixtures, not physical iPhone testing.

The current upstream engine release was rechecked as v0.3.68. KIM's latest-release page could not be fetched during this run; this package continues the conversation build rather than claiming a fresh upstream KIM download.

On iPhone, verify Red with KIM sprites ON and OFF, change ENEMY PKMN SIZE from 100% to 200%, rotate, and check Route 10/Lavender approaches. Extended art is shared by scene family, so individual variants may still have visible artistic joins even with the correct environment family.
