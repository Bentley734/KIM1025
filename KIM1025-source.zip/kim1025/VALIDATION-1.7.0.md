# KIM1025 1.7.0 validation

Validated on October 10, 2026 against the supplied gen1recomp 0.3.71 source. Headless LuaJIT execution used the Lua framework bundled with the installed gen1recomp app. All 81 Lua files compile.

| Check | Result |
|---|---|
| aspect_backgrounds.lua | PASS: 8648 complete-aspect background and original anchor checks |
| asset_manager_gen3.lua | PASS: 339 assertions; Gen3 menu activation, real stack, input/update/draw/close, download initiation/cancel, visible errors and Gen1/2 behavior. |
| asset_upgrade.lua | PASS: 6 asset upgrade checks |
| flat_world_orientation.lua | PASS: 104 flat-world checks using actual Renderer:endFrame; PASS: 124 flat-world and all-platform single-arena checks |
| gen3_packaged_background.lua | PASS: 174 presenter/compositor assertions |
| gen3_party_guard.lua | PASS: 20 party save-safety checks |
| gen3_update.lua | PASS: 274 Gen3 integration checks |
| hoenn_backgrounds.lua | Hoenn background checks	134 |
| hoenn_bridge.lua | KIM production bridge checks	10 |
| portrait_backgrounds.lua | PASS: 8648 complete-aspect background and original anchor checks |
| portrait_battle.lua | PASS: 174 presenter/compositor assertions |
| portrait_battler_alignment.lua | PASS: 118 portrait alignment checks; PASS: 150 alignment and actual Gen 1 draw checks |
| world_orientation.lua | World orientation: 73 checks passed against /Users/johnmartin/Downloads/Codex/work/engine/gen1recomp-0.3.71 |

The Gen 3 integration test executes the real 0.3.71 FRLG and RSE option-menu modules with isolated dependencies. Every registered setting is reachable through the KIM1025 root or its groups in FireRed, LeafGreen, Ruby, Sapphire and Emerald. Start-menu deduplication, native action delegation, special-menu exclusion and fork-ID persistence pass. Cooperative sprite-provider tests use an API fixture that reasserts its ownership, rather than a bundled 1025Dex release.

The packaged-background test executes the complete bridge across Windows, Linux, macOS, Android and iOS, with canonical PNG assets absent. Anchor-transform checks cover the shipped widescreen source rectangle. The existing aspect-arena suite covers portrait, widescreen and ultrawide geometry.

The pre-1.7 `tests/dex_compat.lua` suite depends on an external 1025Dex package and asserts the old all-Dex sprite ownership/trim behavior. It is retained for historical reference and was not run; the new cooperative-provider integration checks replace that obsolete contract. A production 1025Dex release was not supplied, so live provider integration still requires gameplay confirmation.

No ROMs, saves, or running game session were modified. No live graphical playthrough, actual network download/extraction of the external supplements, or physical-device validation was performed. Fixtures verify upgrade order and save restoration, including failed battle starts and battle writeback.
