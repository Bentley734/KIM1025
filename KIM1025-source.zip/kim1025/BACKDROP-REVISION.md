# 1.6.27 backdrop revision

The built-in imagegen tool edited field, gym and league portrait extensions. The other twelve images were inspected and retain their flat scenery without additional battle platforms. The runtime aligns each profile's ground boundary with the source battlefield, using uniform overscan to avoid sky beneath the source ground and uncovered viewport edges.

Prompt set: preserve the existing painted style, environment, lighting and portrait proportions; remove field battle patches and gym/league arena rings; replace them with continuous meadow grass or flat marble tiles; no mounds, battle pads, characters, text or UI. The field edit also raises the horizon to approximately the upper 28% of the image.

The original HD images and battle anchors are unchanged. Updated assets are saved in assets/battle/backgrounds/portrait/field.png, gym.png and league.png.
