# 1.6.29 widescreen backdrop artwork

All fifteen scenery profiles have dedicated horizontal 16:9 versions under `assets/battle/backgrounds/widescreen/`. The built-in imagegen tool generated each version from its existing portrait extension as an edit reference.

Prompt set: naturally extend both sides to a 16:9 composition; preserve the distinctive setting, painterly game illustration style, palette and lighting; keep a high horizon and expansive continuous terrain or floor; avoid battle mounds, oval patches, arena rings, combat platforms, Pokémon, people, text or UI. Field: continuous meadow grass and flowers. Gym and league: rectangular marble floor tiles without arena circles.

The runtime selects these files when viewport aspect is at least 1.6. Other aspect ratios retain the existing portrait scenery. Original HD battlefield images and sprite anchors remain unchanged.
