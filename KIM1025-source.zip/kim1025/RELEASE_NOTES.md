## 1.7.3 — Persistent in-app KIM1025 assets

The installable mod ZIP is now about 9 MB. The 216 portrait, widescreen and ultrawide battle backgrounds live in an independently versioned KIM1025 artwork pack, downloaded once into the persistent mod cache. Future code updates retain this cache and do not require another 400+ MB download.

Open KIM ASSETS in the main KIM asset downloader. DOWNLOAD ALL installs missing original KIM packs, then KIM1025 assets. DOWNLOAD KIM1025 installs only the new artwork pack. Users with original KIM assets already installed are prompted for KIM1025 assets after updating. B defers the prompt; the download remains available in KIM ASSETS. Existing packaged artwork can migrate locally when upgrading in place; a clean small mod installation downloads the artwork.

Install `kim1025-1.7.3.zip`, close the game, replace `mods/kim1025` with its extracted `kim1025` folder, retain the downloaded asset cache, and restart. Accept the in-app download prompt. `KIM1025-assets-v1.0.0.zip` is an artwork pack used by the downloader, not an installable mod ZIP. Pack version 1.0.0 remains independent of code version 1.7.3. Keep release v1.7.3 and its asset ZIP available for future clients.

Each downloaded artwork file is SHA-256 checked before installation. Completion is recorded only after extraction and metadata/index writes succeed. Original KIM and KIM1025 packs use separate cache namespaces and separate removal indexes. Cancelling an asset download defers missing packs, and retry resumes the failing pack without restarting installed original packs. The existing portable and mobile download paths are reused.

Validation: all 17 runnable headless suites pass and 86 Lua files compile, including 426 hub-flow checks and 90 production ZIP/cache checks. Full-pack validation in the installed Mac LÖVE runtime passed 12 checks, verified all 216 real artwork hashes, and decoded portrait, widescreen and ultrawide art. Full ROM and physical phone gameplay remain unverified.

# KIM1025 1.7.2

Fixes small or misplaced player trainers in mobile HD battle intros. Trainers now draw once, at the authored player platform, at a readable size that scales with the arena rather than the native UI. ROM/default trainer art and BATTLE SPRITES OFF use the same alignment. Native slide timing, animation, desktop presentation, Safari/demo scenes, and external stage ownership are preserved.

Includes the v1.7.1 player Pokemon animation fix and all supporting libraries, data, and packaged artwork.

Install the complete KIM1025-v1.7.2.zip: close the game, replace mods/kim1025 with its extracted kim1025 folder, retain the external downloaded asset cache, and restart. Avoid a nested kim1025/kim1025 folder. The small hotfix is an overlay: merge into an existing full installation and keep assets.

Validation: 15 runnable headless suites pass, including 82 trainer-intro checks; 83 Lua files compile. The previous build reproduces the trainer scale failure. The installed Mac game's LÖVE runtime rendered the production trainer code and actual art in an isolated test scene at 1320x2868 and 660x1434; 9 GPU checks pass and visible trainer contact is within one pixel of the platform anchor. This was a renderer fixture, not a full ROM gameplay test or physical iPhone test.

---

# KIM1025 1.7.1

Includes the Gen 1/2 player battle-sprite animation hotfix and every required supporting library, including lib/flat_world_orientation.lua. This is a complete mod package.

## Install

Close Gen1Recomp, extract KIM1025-v1.7.1.zip, and replace the old mods/kim1025 folder with the extracted kim1025 folder. Confirm main.lua and lib/flat_world_orientation.lua are directly under that folder; avoid a nested kim1025/kim1025 directory. Retain the external downloaded KIM asset cache, then restart the game.

Use the complete release ZIP for installation. The earlier six-file hotfix was an overlay and could not replace a full mod folder.

## Fixes

- Restores Gen 1/2 player battle-sprite animation when an inherited native scissor clips the cached sprite canvas.
- Retains the same cached drawable while advancing animation frames, fixes front/back virtual-path routing, and preserves host clipping and animation/sprite toggle behavior.
- Includes all libraries, data, and packaged artwork to prevent missing-file load failures after folder replacement.
- Includes the Gen 3 compatibility and Kanto in Motion 1.7.0 updates from the preceding release.

Validation: all 14 runnable headless suites pass and all 82 Lua files compile. ZIP integrity and supporting-file completeness pass. Live device gameplay and the separate production 1025Dex integration remain unverified.

---

# KIM1025 1.7.0

Updated from the supplied KIM1025 1.6.31 and Kanto in Motion 1.7.0 packages for gen1recomp 0.3.71.

- Gen 3 Start Menu → KIM1025 opens the complete native settings page. UI SETTINGS and BATTLE SETTINGS expose the complete schema, including player/enemy size. OPTIONS also retains KIM1025 and ASSETS access; OPTIONS → MODS → KIM1025 uses the expanded registered schema.
- Gen 3 HD backgrounds can use KIM1025's packaged complete arenas when the external PNG pack is absent. Embedded platform coordinates are respected. HD BATTLE BACKGROUNDS OFF restores the native field. Hoenn environments without suitable art retain their native scenes.
- Adds upstream Gen 3 Modern menus, dialogue, naming, Trainer Card, storage, Summary, Pokédex and lower battle panels, readability fixes and controller navigation improvements.
- Adds cooperative 1025Dex routing: supported #001–386 HD art uses KIM, expanded species retain the Dex art provider. Missing HD files fall back safely. Turning BATTLE SPRITES off restores the provider.
- Adds upstream Unown/Deoxys form metadata, layered asset upgrades, Gen 2 Summary and Battle Art compatibility, and responsive UI fixes.
- Preserves the kim1025 mod ID, existing settings/cache ownership, custom portrait/widescreen/ultrawide arenas, Gen 1 sizing controls and mobile/iOS corrections. General UI font scale now follows upstream's 200% cap.

## Install

Replace the old kim1025 folder with this package's kim1025 folder in your mods directory. Keep only one KIM1025 copy and disable the standalone Kanto in Motion mod; they replace the same presentation layers. Restart the game session after replacement.

Open Start Menu → KIM1025 → BATTLE SETTINGS for HD backgrounds and battler sizing. HD ASSET MANAGER is available from the KIM1025 page and ASSETS from OPTIONS. Existing base artwork is retained; the manager downloads the missing 1.1.0 Unown and 1.2.0 Deoxys supplements in order. Packaged backgrounds do not require that download.

Validation is headless against supplied 0.3.71 engine code. No live ROM playthrough or graphical confirmation has been performed. See VALIDATION-1.7.0.md.
