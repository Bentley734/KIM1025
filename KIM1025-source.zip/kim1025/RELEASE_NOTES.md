# KIM1025 1.7.7 — focused features

Keep animated Pokédex sprites, HD battle backgrounds, trainer choices and the 165 Gen 1 move animations. Remove the other bundled features and reduce settings to one short native page.

Preserve the iOS/Android layout, orientation, Retina scaling, touch boundaries, trainer grounding and move/catch alignment fixes. Saved alignment preferences remain usable internally. Native/1025Dex Pokémon providers remain authoritative; the Gen 1 native picture layer is no longer skipped when both Pokémon are replayed over HD art.

Replace the complete previous mod folder, keep the downloaded cache, and restart. Background pack 1.0.0 is unchanged, so already downloaded artwork is reused.

Validation: 19 suites, 55 Lua compilation checks, 225 additional checks against the installed 1025Dex hook, 26 provider GPU checks and 9 trainer GPU checks. Full ROM and physical iPhone gameplay remain unverified.
