# KIM1025 1.7.13 — Native Fit trainer ownership

Fixes the actual macOS default Native Fit path, which bypassed the preceding trainer correction. The trainer source is suppressed and painted once on the transformed left platform using the corrected desktop scale. Native Fit footer geometry now handles its separate Y scale. iOS trainer baselines move down further, preserving size and intro timing.

Inspected installed 1025Dex, WildFollowers and Battle UI Customizer hooks; the trainer placement fault belongs to KIM1025. No companion mod changes are required.

Validation: all 20 suites pass; 46 Lua files compile; regression tests execute the production Native Fit producer and source suppression. 17 local GPU checks pass. Physical iPhone and full live gameplay remain unverified.

Replace the entire old mod folder, keep downloaded assets, and restart.
