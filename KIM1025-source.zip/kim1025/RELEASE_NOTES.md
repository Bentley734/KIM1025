# KIM1025 1.7.9 — clear move menu

Replaces the Gen 1 HD-battle move strip with a dedicated GBA-style two-column grid and a separate PP/type panel. Draws glyphs with equal physical X/Y scale and integer enlargement; avoids capturing the Gen 1 type box above the cropped bottom strip. Supports grid input, move swapping, current PP and PP Ups, empty slots and disabled moves. FR/LG and Emerald keep their native battle menus.

Preserves iOS/portrait alignment, the four retained features and the 1.7.8 removal of 3D integrations. Replace the complete mod folder, keep the asset cache, and restart.

Validation: 19 suites pass and 45 Lua files compile; the production panel also rendered on the local LÖVE GPU with the actual engine font. Physical iPhone gameplay remains unverified.
