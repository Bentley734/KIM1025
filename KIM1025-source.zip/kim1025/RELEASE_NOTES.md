## 1.6.31 — Complete 32:9 HD arenas

- Add 72 complete ultrawide backgrounds, selected automatically on 32:9 displays.
- Blend location-specific panorama scenery around the original arena, preserving original mounds and Pokémon alignment.
- Clear inherited menu clipping during the full-screen arena draw to prevent black side bars.

Install: replace your KIM1025 mod folder with `kim1025` from the ZIP. Keep the existing downloaded KIM asset cache. See `ULTRAWIDE-ART.md` for authoring and validation details.

## 1.6.30 — Complete portrait and widescreen HD arenas

- Replace layered backdrops with 144 complete HD arenas for portrait and widescreen layouts.
- Preserve original mound geometry and existing Pokémon alignment.
- Match surrounding scenery to all 36 original locations and their existing time variants.
- Remove the backdrop blend shader and retain only the active complete arena texture.

Install: replace your KIM1025 mod folder with `kim1025` from the ZIP. Keep the existing downloaded KIM asset cache.

Validation: Lua syntax, alignment and renderer regressions pass; all 144 images decode with expected dimensions. Platform renderer tests cover Windows, Linux, macOS, Android and iOS using test doubles. Physical devices were not tested. Existing generation-specific native background paths remain available.
