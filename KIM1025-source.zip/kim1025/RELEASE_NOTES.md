# KIM1025 1.7.10 — landscape and Emerald menu compatibility

Routes the dedicated Gen 1 HD move menu through the final-window renderer in landscape and on desktop as well as portrait. Removes the old native move strip and suppresses its source draw, including after Battle UI Customizer loads. Messages and child menus retain their source owners.

Uses Battle UI Customizer 1.0.7’s exported Emerald panel (including imported Emerald art) and opacity compositor. Text keeps uniform physical scale and full opacity. Explicit maxPp values are honored. FR/LG and Emerald retain their native menus. All retained features, iOS alignment fixes and removal of 3D integrations are preserved.

Validation: 20 suites passed, 46 Lua files compiled, 27 actual compositor-routing checks, and 18 local GPU checks with the actual Customizer and engine font across desktop, landscape, portrait and 100/50/0 panel opacity. Physical iPhone gameplay remains unverified.

Replace the entire old mod folder, keep downloaded assets, and restart.
