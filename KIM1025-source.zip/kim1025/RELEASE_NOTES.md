# KIM1025 1.7.14 — macOS dialogue trainer anchor

Desktop HD trainer size now follows battlefield width at a larger scale. The visible bottom is pinned to the actual native dialogue top using Renderer frameRects, accounting for Retina DPI, UI zoom and letterbox/position lift. Retains the left-platform X position. iOS sizing and placement are unchanged.

Validation: all 20 suites pass, 46 Lua files compile, and 135 trainer assertions pass, including a physical-pixel dialogue anchor check.

Replace the entire old mod folder, keep downloaded assets, and restart.
