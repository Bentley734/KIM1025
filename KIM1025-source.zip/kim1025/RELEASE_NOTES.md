# KIM1025 1.7.8 — remove 3D integrations

Removed all bundled Battle Art / PotatoVoxel model-stage adapters, their startup installers, staged Pokémon providers and optional dependencies. Legacy stage registration is refused. Retains animated Pokédex sprites, HD flat battle backgrounds, trainer choices, move animations, and the flat renderer’s iOS orientation and alignment fixes.

Replace the entire old mod folder and restart; keep the downloaded asset cache. Separately installed 3D mods retain their own controls.
