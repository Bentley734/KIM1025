# KIM1025 1.7.15 — portrait trainer baseline

Lowers the iOS portrait intro trainer by another 80 arena pixels, scaled to the battlefield width (55 physical pixels at 1320px width). Trainer size, iOS landscape placement and macOS dialogue anchoring remain unchanged.

Validation: all 20 suites pass and 46 Lua files compile, including orientation-specific trainer geometry checks.

Replace the entire old mod folder, keep downloaded assets, and restart.
