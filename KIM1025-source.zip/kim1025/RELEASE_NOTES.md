# KIM1025 1.7.12 — trainer scale and placement

Gen 1 HD trainers use arena sizing on desktop instead of the native UI/Retina rung. Desktop size is capped to battlefield width so tall windows cannot enlarge the trainer through the background cover scale. The iOS portrait trainer is 25% larger and lower; landscape keeps its size with a smaller downward adjustment. Native intro slide timing and all trainer choices remain supported.

Preserves Vanilla/Emerald move frames, iOS fixes, retained features and removal of 3D integrations.

Validation: 20 suites pass; 46 Lua files compile; 133 trainer assertions and 17 real GPU checks at desktop and phone resolutions pass. Physical iPhone gameplay remains unverified.

Replace the entire old mod folder, keep downloaded assets, and restart.
