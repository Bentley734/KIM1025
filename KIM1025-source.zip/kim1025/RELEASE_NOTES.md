# KIM1025 1.7.11 — matching move menu frames

Gen 1 HD move selection now uses the native game frame with Battle UI Customizer Vanilla style. Emerald style uses the imported Emerald frame with fixed corners and a thick red rim on both the moves and PP/type panels; a matching red fallback is available without an Emerald import. Panel opacity and full-opacity text are preserved.

Preserves landscape/portrait/desktop routing, iOS and alignment fixes, retained features and removal of 3D integrations.

Validation: all 20 suites pass and all 46 Lua files compile. Local GPU checks use the actual Battle UI Customizer 1.0.7, engine font and decoded Emerald cache across both styles and three orientations at 100/50/0 opacity. Physical iPhone gameplay remains unverified.

Replace the entire old mod folder, keep downloaded assets, and restart.
