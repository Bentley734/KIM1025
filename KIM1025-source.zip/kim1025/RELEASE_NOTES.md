## 1.7.6 — Live 1025Dex battle sprites and settings submenus

KIM's fullscreen Gen 1 battle scene now calls the active battle.mon_pic provider for each player and enemy frame. This allows 1025Dex to supply its own artwork and animation clock even while KIM suppresses the duplicate native sprite layer. The provider's pending signal hides the sprite until its custom sheet is ready, instead of flashing vanilla art. Available KIM metadata no longer displaces a claimed 1025Dex sprite. Native picImage resolution also retains the external provider's live image. Existing 1025Dex animation options and intentional pauses are preserved.

Settings now use Pokemon, Battle, Interface, Title Screen and Advanced submenus, including smaller Battle and Interface pages. Existing saved values are preserved; KIM Assets remains on the main page.

Install kim1025-1.7.6.zip (about 9 MB), replace mods/kim1025, keep 1025Dex and WildFollowers enabled, preserve downloaded asset caches, and fully restart Gen1Recomp. No artwork redownload is required for this code change.

Validation: all 20 automated suites pass and 92 Lua files compile. The installed 1025Dex 1.2.34 live scene hook and actual animation clock pass 233 provider/suppression checks, including front/back animation resuming after EE pauses. The regression fails against v1.7.5. The installed Mac LOVE graphics runtime passes 26 GPU checks with the actual Dex hook/clock. Full ROM gameplay and physical iOS testing remain unverified.

## 1.7.5 — Gen 1 battle sprite conflict with 1025Dex

Fixes a second sprite provider drawing over KIM's continuously animated Pokemon. 1025Dex can replace KIM's transparent native-slot sprite inside its own pics-layer wrapper. KIM now resolves the final native picImage boundary: it suppresses that covering copy in the HD scene, and supplies the current KIM frame in native battle presentation. The guard applies to both player and enemy, independent of mod load order. It yields when KIM battle sprites are disabled or their source is unavailable, and preserves trainer and send-out ownership.

Install `kim1025-1.7.5.zip` (about 9 MB), replace `mods/kim1025`, keep the downloaded asset cache, and fully restart the game. 1025Dex and WildFollowers can remain enabled. The asset pack stays at version 1.0.0 and does not need downloading again.

Validation: 18 runnable suites passed and 88 Lua files compiled. The new regression checks both load orders and repeated player/enemy loops (108 checks), also passing against the installed 1025Dex 1.2.34 Gen 1 wrapper. The installed Mac LOVE runtime passed 52 GPU checks, including 24 live player/enemy frame checks composited through that actual Dex wrapper. Full ROM and physical phone gameplay remain unverified.

## 1.7.4 — Downloader selector and Gen 1 battle animation

The KIM ASSETS downloader now draws a visible selection arrow beside the selected download or removal option, independent of the game's font.

Red/Blue/Yellow battle constructors receive HD Pokemon art as soon as its assets are available. Native battle draws use an immutable image for each animation frame so image-processing caches cannot freeze a reused canvas; the fullscreen HD pass uses the same frame-safe presentation. Animation continues across repeated loops. Missing assets retain vanilla fallback, and ANIMATION OFF still holds the first frame.

Install `kim1025-1.7.4.zip` (about 9 MB), replace the installed `mods/kim1025` folder, keep the downloaded asset cache, and restart. The existing KIM1025 artwork pack remains version 1.0.0, served from release v1.7.3; installed artwork does not need another download.

Validation: 17 runnable regression suites passed; 86 Lua files compiled. Includes 930 downloader checks and 73 battle constructor/animation checks. The installed Mac LOVE runtime passed 28 GPU checks for selector positioning and repeated animation through an image-processing cache. Full ROM and physical phone gameplay remain unverified.

## 1.7.3 — Persistent in-app KIM1025 assets

The installable mod ZIP is now about 9 MB. The 216 portrait, widescreen and ultrawide battle backgrounds live in an independently versioned KIM1025 artwork pack, downloaded once into the persistent mod cache. Future code updates retain this cache and do not require another 400+ MB download.

Open KIM ASSETS in the main KIM asset downloader. DOWNLOAD ALL installs missing original KIM packs, then KIM1025 assets. DOWNLOAD KIM1025 installs only the new artwork pack. Users with original KIM assets already installed are prompted for KIM1025 assets after updating. B defers the prompt; the download remains available in KIM ASSETS. Existing packaged artwork can migrate locally when upgrading in place; a clean small mod installation downloads the artwork.

Install `kim1025-1.7.3.zip`, close the game, replace `mods/kim1025` with its extracted `kim1025` folder, retain the downloaded asset cache, and restart. Accept the in-app download prompt. `KIM1025-assets-v1.0.0.zip` is an artwork pack used by the downloader, not an installable mod ZIP. Pack version 1.0.0 remains independent of code version 1.7.3. Keep release v1.7.3 and its asset ZIP available for future clients.

Each downloaded artwork file is SHA-256 checked before installation. Completion is recorded only after extraction and metadata/index writes succeed. Original KIM and KIM1025 packs use separate cache namespaces and separate removal indexes. Cancelling an asset download defers missing packs, and retry resumes the failing pack without restarting installed original packs. The existing portable and mobile download paths are reused.

Validation: all 17 runnable headless suites pass and 86 Lua files compile, including 426 hub-flow checks and 90 production ZIP/cache checks. Full-pack validation in the installed Mac LÖVE runtime passed 12 checks, verified all 216 real artwork hashes, and decoded portrait, widescreen and ultrawide art. Full ROM and physical phone gameplay remain unverified.

# KIM1025 1.7.2

Fixes small or misplaced player trainers in mobile HD battle intros. Trainers now draw once, at the authored player platform, at a readable size that scales with the arena rather than the native UI. ROM/default trainer art and BATTLE SPRITES OFF use the same alignment. Native slide timing, animation, desktop presentation, Safari/demo scenes, and external stage ownership are preserved.

Includes the v1.7.1 player Pokemon animation fix and all supporting libraries, data, and packaged artwork.

Install the complete KIM1025-v1.7.2.zip: close the game, replace mods/kim1025 with its extracted kim1025 folder, retain the external downloaded asset cache, and restart. Avoid a nested kim1025/kim1025 folder. The small hotfix is an overlay: merge into an existing full installation and keep assets.

Validation: 15 runnable headless suites pass, including 82 trainer-intro checks; 83 Lua files compile. The previous build reproduces the trainer scale failure. The installed Mac game's LÖVE runtime rendered the production trainer code and actual art in an isolated test scene at 1320x2868 and 660x1434; 9 GPU checks pass and visible trainer contact is within one pixel of the platform anchor. This was a renderer fixture, not a full ROM gameplay test or physical iPhone test.

---

# KIM1025 1.7.1

Includes the Gen 1/2 player battle-sprite animation hotfix and every required supporting library, including lib/flat_world_orientation.lua. This is a complete mod package.

## Install

Close Gen1Recomp, extract KIM1025-v1.7.1.zip, and replace the old mods/kim1025 folder with the extracted kim1025 folder. Confirm main.lua and lib/flat_world_orientation.lua are directly under that folder; avoid a nested kim1025/kim1025 directory. Retain the external downloaded KIM asset cache, then restart the game.

Use the complete release ZIP for installation. The earlier six-file hotfix was an overlay and could not replace a full mod folder.

## Fixes

- Restores Gen 1/2 player battle-sprite animation when an inherited native scissor clips the cached sprite canvas.
- Retains the same cached drawable while advancing animation frames, fixes front/back virtual-path routing, and preserves host clipping and animation/sprite toggle behavior.
- Includes all libraries, data, and packaged artwork to prevent missing-file load failures after folder replacement.
- Includes the Gen 3 compatibility and Kanto in Motion 1.7.0 updates from the preceding release.

Validation: all 14 runnable headless suites pass and all 82 Lua files compile. ZIP integrity and supporting-file completeness pass. Live device gameplay and the separate production 1025Dex integration remain unverified.

---

# KIM1025 1.7.0

Updated from the supplied KIM1025 1.6.31 and Kanto in Motion 1.7.0 packages for gen1recomp 0.3.71.

- Gen 3 Start Menu → KIM1025 opens the complete native settings page. UI SETTINGS and BATTLE SETTINGS expose the complete schema, including player/enemy size. OPTIONS also retains KIM1025 and ASSETS access; OPTIONS → MODS → KIM1025 uses the expanded registered schema.
- Gen 3 HD backgrounds can use KIM1025's packaged complete arenas when the external PNG pack is absent. Embedded platform coordinates are respected. HD BATTLE BACKGROUNDS OFF restores the native field. Hoenn environments without suitable art retain their native scenes.
- Adds upstream Gen 3 Modern menus, dialogue, naming, Trainer Card, storage, Summary, Pokédex and lower battle panels, readability fixes and controller navigation improvements.
- Adds cooperative 1025Dex routing: supported #001–386 HD art uses KIM, expanded species retain the Dex art provider. Missing HD files fall back safely. Turning BATTLE SPRITES off restores the provider.
- Adds upstream Unown/Deoxys form metadata, layered asset upgrades, Gen 2 Summary and Battle Art compatibility, and responsive UI fixes.
- Preserves the kim1025 mod ID, existing settings/cache ownership, custom portrait/widescreen/ultrawide arenas, Gen 1 sizing controls and mobile/iOS corrections. General UI font scale now follows upstream's 200% cap.

## Install

Replace the old kim1025 folder with this package's kim1025 folder in your mods directory. Keep only one KIM1025 copy and disable the standalone Kanto in Motion mod; they replace the same presentation layers. Restart the game session after replacement.

Open Start Menu → KIM1025 → BATTLE SETTINGS for HD backgrounds and battler sizing. HD ASSET MANAGER is available from the KIM1025 page and ASSETS from OPTIONS. Existing base artwork is retained; the manager downloads the missing 1.1.0 Unown and 1.2.0 Deoxys supplements in order. Packaged backgrounds do not require that download.

Validation is headless against supplied 0.3.71 engine code. No live ROM playthrough or graphical confirmation has been performed. See VALIDATION-1.7.0.md.
